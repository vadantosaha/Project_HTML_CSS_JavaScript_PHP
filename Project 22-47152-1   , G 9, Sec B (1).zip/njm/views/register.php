
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Register - Hospital Bed System</title>
    <style>
        body{font-family:Arial,sans-serif;margin:0;background:#f4f6f9}
        .navbar{background:#007bff;padding:15px;color:#fff;display:flex;justify-content:space-between}
        .navbar a{color:#fff;text-decoration:none;margin-left:15px}
        .card{width:360px;margin:40px auto;padding:20px;background:#fff;border-radius:8px;box-shadow:0 0 10px rgba(0,0,0,.1)}
        .form-group{margin-bottom:12px}
        .form-group label{display:block;margin-bottom:4px;font-weight:700}
        .form-group input:not([type=radio]),
        .form-group select,
        .form-group textarea{width:100%;padding:8px;box-sizing:border-box;border:1px solid #ccc;border-radius:4px}
        .radio-group{display:flex;align-items:center;gap:8px;font-weight:400}
        .radio-group label{display:inline;font-weight:400;margin:0}
        .btn{width:100%;padding:10px;background:#28a745;color:#fff;border:none;cursor:pointer;border-radius:4px;margin-top:10px}
        .error{color:red;margin-bottom:10px}
        .auth-footer{text-align:center;margin-top:15px;font-size:14px}  
    </style>
</head>
<body>

<div class="navbar">
    <strong>Bed Management System</strong>
    <div>
        <a href="home.php">Home</a>
        <a href="login.php">Login</a>
    </div>
</div>

<div class="card">
    <h3 style="margin-top: 0; text-align: center; font-size: 32px; color: #007bff; text-shadow: 2px 2px 4px rgba(0,0,0,0.2);"> Create Account </h3>

    <?php if ($error): ?>
        <div class="error"><?= htmlspecialchars($error) ?></div>
    <?php endif; ?>

    <form method="POST">
        <div class="form-group">
            <label>Account Type:</label>
            <input type="radio" name="role_type" value="patient" checked onclick="toggleFields('patient')"> Patient
            <input type="radio" name="role_type" value="hospital" onclick="toggleFields('hospital')"> Hospital
        </div>

        <div id="patientFields">
            <div class="form-group">
                <label>Username</label>
                <input type="text" name="p_username" placeholder="Unique username">
            </div>
            <div class="form-group">
                <label>Full Name</label>
                <input type="text" name="p_name" placeholder="John Doe">
            </div>
            <div class="form-group">
                <label>Phone Number</label>
                <input type="text" name="p_phone" placeholder="+1-555-0000">
            </div>
            <div class="form-group">
                <label>Address</label>
                <input type="text" name="p_address" placeholder="Residential address">
            </div>
        </div>

        <div id="hospitalFields" style="display: none;">
            <div class="form-group">
                <label>Hospital Name</label>
                <input type="text" name="h_name" placeholder="City Medical Center">
            </div>
            <div class="form-group">
                <label>Hospital Type</label>
                <select name="h_type">
                    <option value="Public">Public</option>
                    <option value="Private">Private</option>
                </select>
            </div>
            <div class="form-group">
                <label>Contact Phone</label>
                <input type="text" name="h_phone" placeholder="+1-555-0100">
            </div>
            <div class="form-group">
                <label>Hospital Address</label>
                <input type="text" name="h_address" placeholder="Full address">
            </div>
            <div class="form-group">
                <label>Hospital Details</label>
                <textarea name="h_details" rows="2" placeholder="Facilities & Specialties"></textarea>
            </div>
        </div>

        <div class="form-group">
            <label>Password</label>
            <input type="text" name="password" required placeholder="Account password">
        </div>

        <button type="submit" class="btn">Register</button>
    </form>

    <div class="auth-footer">
        Already registered? <a href="login.php">Sign In</a>
    </div>
</div>

<script>
function toggleFields(role) {
    document.getElementById('patientFields').style.display = (role === 'patient') ? 'block' : 'none';
    document.getElementById('hospitalFields').style.display = (role === 'hospital') ? 'block' : 'none';
}
</script>

</body>
</html>