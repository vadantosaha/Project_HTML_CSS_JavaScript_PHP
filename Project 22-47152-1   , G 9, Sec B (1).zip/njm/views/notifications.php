
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Notifications</title>
    <style>
        body { font-family: Arial, sans-serif; margin: 0; background: #f4f6f9; }
        .navbar { background: #007bff; padding: 15px; color: white; display: flex; justify-content: space-between; }
        .navbar a { color: white; text-decoration: none; margin-left: 15px; }
        .container { max-width: 700px; margin: 30px auto; padding: 20px; background: white; border-radius: 8px; box-shadow: 0 0 10px rgba(0,0,0,0.1); }
        .header-bar { display: flex; justify-content: space-between; align-items: center; border-bottom: 2px solid #e9ecef; padding-bottom: 10px; margin-bottom: 20px; }
        .btn { padding: 6px 12px; color: white; border: none; cursor: pointer; border-radius: 4px; text-decoration: none; font-size: 13px; display: inline-block; }
        .btn-outline { background: transparent; color: #007bff; border: 1px solid #007bff; }
        .notification-list { display: flex; flex-direction: column; gap: 10px; }
        .notification-item { display: flex; gap: 15px; padding: 12px; border-radius: 6px; border-left: 4px solid #ccc; background: #f8f9fa; }
        .notification-item.unread { border-left-color: #007bff; background: #eef5ff; }
        .notif-icon { font-size: 18px; }
        .notif-content p { margin: 0 0 5px 0; font-size: 14px; color: #333; }
        .notif-time { font-size: 11px; color: #777; }
        .alert { padding: 15px; background: #d1ecf1; color: #0c5460; border-radius: 4px; }
    </style>
</head>
<body>

<div class="navbar">
    <strong>Bed Management System</strong>
    <div>
        <a href="home.php">Home</a>
        <a href="doctor-details.php">Find Doctors</a>
        <a href="<?= ($userType === 'patient') ? 'patient-dashboard.php' : 'hospital-dashboard.php' ?>">Dashboard</a>
        <a href="logout.php">Logout</a>
    </div>
</div>

<div class="container">
    <div class="header-bar">
        <h2 style="margin: 0;">System Notifications</h2>
        <?php if (!empty($notifications)): ?>
            <a href="notifications.php?action=mark_read" class="btn btn-outline">Mark All as Read</a>
        <?php endif; ?>
    </div>

    <?php if (empty($notifications)): ?>
        <div class="alert">You have no notifications at this time.</div>
    <?php else: ?>
        <div class="notification-list">
            <?php foreach ($notifications as $n): ?>
                <div class="notification-item <?= ($n['N_Status'] === 'Unread') ? 'unread' : 'read' ?>">
                    <div class="notif-icon"><?= ($n['N_Status'] === 'Unread') ? '🔔' : '✓' ?></div>
                    <div class="notif-content">
                        <p><?= htmlspecialchars($n['N_Message']) ?></p>
                        <span class="notif-time">📅 <?= htmlspecialchars($n['N_Date']) ?></span>
                    </div>
                </div>
            <?php endforeach; ?>
        </div>
    <?php endif; ?>
</div>

</body>
</html>