
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Hospital & Bed Search</title>
    <style>
        body { font-family: Arial, sans-serif; margin: 0; background: #f4f6f9; }
        .navbar { background: #007bff; padding: 15px; color: white; display: flex; justify-content: space-between; align-items: center; }
        .navbar a { color: white; text-decoration: none; margin-left: 15px; }
        .badge-count { background: #dc3545; color: white; border-radius: 50%; padding: 2px 7px; font-size: 11px; margin-left: 4px; font-weight: bold; }
        .container { max-width: 1000px; margin: 20px auto; padding: 0 15px; }
        .search-card { background: white; padding: 20px; border-radius: 8px; box-shadow: 0 0 10px rgba(0,0,0,0.1); margin-bottom: 20px; }
        
        .filter-grid { display: flex; gap: 10px; flex-wrap: wrap; align-items: flex-end; }
        .filter-item { flex: 1; min-width: 180px; display: flex; flex-direction: column; }
        .filter-item label { display: block; margin-bottom: 5px; font-weight: bold; }
        .filter-item input, .filter-item select { width: 100%; padding: 8px; box-sizing: border-box; height: 38px; border: 1px solid #ccc; border-radius: 4px; }
        
        .btn { padding: 9px 15px; background: #007bff; color: white; border: none; cursor: pointer; border-radius: 4px; text-decoration: none; display: inline-block; height: 38px; box-sizing: border-box; }
        .btn-success { background: #28a745; }
        .btn-block { width: 100%; margin-top: 0; }

        .hospital-grid { display: grid; grid-template-columns: repeat(auto-fill, minmax(300px, 1fr)); gap: 20px; }
        .hospital-card { background: white; border-radius: 8px; padding: 15px; box-shadow: 0 0 8px rgba(0,0,0,0.08); display: flex; flex-direction: column; justify-content: space-between; }
        .stats-row { display: flex; justify-content: space-between; margin: 15px 0; background: #e9ecef; padding: 10px; border-radius: 5px; }
        .card-actions { display: flex; gap: 10px; margin-top: 10px; }
        .alert { padding: 15px; background: #fff3cd; color: #856404; border-radius: 4px; }
    </style>
</head>
<body>

<div class="navbar">
    <strong>Bed Management System</strong>
    <div>
        <a href="home.php">Home</a>
        <a href="doctor-details.php">Find Doctors</a>
        <a href="feedback.php">Feedback</a>
        <?php if (isset($_SESSION['role'])): ?>
            <?php if ($_SESSION['role'] === 'patient'): ?>
                <a href="patient-dashboard.php">Patient Dashboard</a>
            <?php elseif ($_SESSION['role'] === 'hospital'): ?>
                <a href="hospital-dashboard.php">Hospital Dashboard</a>
            <?php endif; ?>
            
            <a href="notifications.php">
                Notifications 
                <?php if ($unreadCount > 0): ?>
                    <span class="badge-count"><?= $unreadCount ?></span>
                <?php endif; ?>
            </a>
            
            <a href="logout.php">Logout (<?= htmlspecialchars($_SESSION['user_name'] ?? '') ?>)</a>
        <?php else: ?>
            <a href="login.php">Login</a>
            <a href="register.php">Register</a>
        <?php endif; ?>
    </div>
</div>

<div class="container">
    <h2>Find Hospitals & Available Beds</h2>

    <div class="search-card">
        <!-- ADDED ID TO FORM FOR AJAX TARGETING -->
        <form id="searchForm" method="GET" action="home.php">
            <div class="filter-grid">
                <div class="filter-item">
                    <label>Hospital Name</label>
                    <input type="text" id="hospital_name" name="hospital_name" value="<?= htmlspecialchars($searchHospital) ?>" placeholder="e.g. City Hospital">
                </div>
                <div class="filter-item">
                    <label>Hospital Type</label>
                    <select id="hospital_type" name="hospital_type">
                        <option value="">All Types</option>
                        <option value="Public" <?= ($searchHospitalType==='Public')?'selected':'' ?>>Public</option>
                        <option value="Private" <?= ($searchHospitalType==='Private')?'selected':'' ?>>Private</option>
                    </select>
                </div>
                <div class="filter-item">
                    <label>Location</label>
                    <input type="text" id="location" name="location" value="<?= htmlspecialchars($searchLocation) ?>" placeholder="e.g. Downtown">
                </div>
                <div class="filter-item">
                    <label>Bed Type</label>
                    <select id="bed_type" name="bed_type">
                        <option value="">All Types</option>
                        <option value="ICU" <?= ($searchBedType==='ICU')?'selected':'' ?>>ICU</option>
                        <option value="CCU" <?= ($searchBedType==='CCU')?'selected':'' ?>>CCU</option>
                        <option value="General" <?= ($searchBedType==='General')?'selected':'' ?>>General</option>
                        <option value="Emergency" <?= ($searchBedType==='Emergency')?'selected':'' ?>>Emergency</option>
                    </select>
                </div>
                <div class="filter-item">
                    <button type="submit" class="btn btn-block">Search</button>
                </div>
            </div>
        </form>
    </div>

    <!-- ADDED ID TO RESULTS CONTAINER FOR AJAX TARGETING -->
    <div id="resultsContainer">
        <h3>Available Hospitals (<?= count($hospitals) ?>)</h3>

        <?php if (empty($hospitals)): ?>
            <div class="alert">No matching hospitals found.</div>
        <?php else: ?>
            <div class="hospital-grid">
                <?php foreach ($hospitals as $h): ?>
                    <?php
                        $bStmt = mysqli_prepare($conn, "SELECT COUNT(*) as total, SUM(CASE WHEN B_Status = 'Available' THEN 1 ELSE 0 END) as avail FROM bed WHERE H_ID = ?");
                        mysqli_stmt_bind_param($bStmt, "i", $h['H_ID']);
                        mysqli_stmt_execute($bStmt);
                        $bedStats = mysqli_fetch_assoc(mysqli_stmt_get_result($bStmt));

                        $dStmt = mysqli_prepare($conn, "SELECT COUNT(*) as doc_count FROM doctor WHERE H_ID = ?");
                        mysqli_stmt_bind_param($dStmt, "i", $h['H_ID']);
                        mysqli_stmt_execute($dStmt);
                        $docData = mysqli_fetch_assoc(mysqli_stmt_get_result($dStmt));
                    ?>
                    <div class="hospital-card">
                        <div>
                            <h3> Hospital Name: <?= htmlspecialchars($h['H_Name']) ?></h3>
                            <p> Hospital Address: <?= htmlspecialchars($h['H_Address']) ?></p>
                            <p> Hospital Phone: <?= htmlspecialchars($h['H_Phone']) ?></p>

                            <div class="stats-row">
                                <span><strong>Beds Available:</strong> <?= $bedStats['avail'] ?? 0 ?></span>
                                <span><strong>Doctors:</strong> <?= $docData['doc_count'] ?? 0 ?></span>
                            </div>
                        </div>

                        <div class="card-actions">
                            <?php if (isset($_SESSION['role']) && $_SESSION['role'] === 'patient'): ?>
                                <a href="admission.php?hospital_id=<?= $h['H_ID'] ?>" class="btn btn-success" style="flex:1; text-align:center;">Book Bed</a>
                            <?php else: ?>
                                <a href="login.php" class="btn btn-success" style="flex:1; text-align:center;" onclick="alert('Please login as a patient to book a bed.');">Book Bed</a>
                            <?php endif; ?>
                        </div>
                    </div>
                <?php endforeach; ?>
            </div>
        <?php endif; ?>
    </div>
</div>

<!-- 
 * ADDED CLIENT-SIDE AJAX SCRIPT HERE:
 * HOW: Listens for user input and form submit events, gathers form parameters using URLSearchParams, 
 * sends an asynchronous Fetch request with 'X-Requested-With: XMLHttpRequest' header, and updates #resultsContainer innerHTML.
 * WHY: Enables real-time background search/filtering without refreshing or flickering the entire webpage.
 -->
<script>
document.addEventListener('DOMContentLoaded', function() {
    const searchForm = document.getElementById('searchForm');
    const resultsContainer = document.getElementById('resultsContainer');

    function fetchResults() {
        const formData = new FormData(searchForm);
        const params = new URLSearchParams(formData);
        params.append('ajax', '1');

        fetch('home.php?' + params.toString(), {
            method: 'GET',
            headers: {
                'X-Requested-With': 'XMLHttpRequest'
            }
        })
        .then(response => response.text())
        .then(html => {
            resultsContainer.innerHTML = html;
        })
        .catch(err => console.error('AJAX fetch error:', err));
    }

    // Intercept form submission to prevent full page refresh
    searchForm.addEventListener('submit', function(e) {
        e.preventDefault();
        fetchResults();
    });

    // Real-time dynamic updates on input/select change
    const inputs = searchForm.querySelectorAll('input, select');
    inputs.forEach(input => {
        input.addEventListener('input', fetchResults);
        input.addEventListener('change', fetchResults);
    });
});
</script>

</body>
</html>