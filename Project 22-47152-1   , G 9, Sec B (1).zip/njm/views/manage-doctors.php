
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Manage Doctors</title>
    <style>
        body { font-family: Arial, sans-serif; margin: 0; background: #f4f6f9; }
        .navbar { background: #007bff; padding: 15px; color: white; display: flex; justify-content: space-between; }
        .navbar a { color: white; text-decoration: none; margin-left: 15px; }
        .container { max-width: 1000px; margin: 30px auto; padding: 20px; background: white; border-radius: 8px; box-shadow: 0 0 10px rgba(0,0,0,0.1); }
        .header-bar { display: flex; justify-content: space-between; align-items: center; border-bottom: 2px solid #e9ecef; padding-bottom: 10px; margin-bottom: 20px; }
        .split-row { display: flex; gap: 20px; flex-wrap: wrap; }
        .form-card { flex: 1; min-width: 280px; background: #f8f9fa; padding: 15px; border-radius: 6px; border: 1px solid #dee2e6; }
        .table-card { flex: 2; min-width: 320px; }
        .form-group { margin-bottom: 12px; }
        .form-group label { display: block; margin-bottom: 5px; font-weight: bold; font-size: 13px; }
        .form-group input { width: 100%; padding: 8px; box-sizing: border-box; border: 1px solid #ccc; border-radius: 4px; }
        .btn { padding: 8px 12px; color: white; border: none; cursor: pointer; border-radius: 4px; text-decoration: none; font-size: 13px; display: inline-block; }
        .btn-primary { background: #007bff; width: 100%; }
        .btn-secondary { background: #6c757d; }
        .btn-danger { background: #dc3545; padding: 4px 8px; font-size: 12px; }
        table { width: 100%; border-collapse: collapse; }
        th, td { border: 1px solid #dee2e6; padding: 8px 10px; text-align: left; font-size: 14px; }
        th { background: #f8f9fa; }
        .alert { padding: 10px; border-radius: 4px; margin-bottom: 15px; font-size: 14px; }
        .alert-danger { background: #f8d7da; color: #721c24; }
        .alert-success { background: #d4edda; color: #155724; }
        .badge { background: #e2e3e5; padding: 3px 6px; border-radius: 4px; font-size: 12px; }
    </style>
</head>
<body>

<!-- Integrated Navbar -->
<div class="navbar">
    <strong>Bed Management System</strong>
    <div>
        <a href="home.php">Home</a>
        <a href="hospital-dashboard.php">Dashboard</a>
        <a href="logout.php">Logout</a>
    </div>
</div>

<div class="container">
    <div class="header-bar">
        <h2 style="margin:0;">Hospital Doctors Directory</h2>
        <a href="hospital-dashboard.php" class="btn btn-secondary">Back to Dashboard</a>
    </div>

    <?php if ($error): ?><div class="alert alert-danger"><?= htmlspecialchars($error) ?></div><?php endif; ?>
    <?php if ($success): ?><div class="alert alert-success"><?= htmlspecialchars($success) ?></div><?php endif; ?>

    <div class="split-row">
        <!-- Add Form -->
        <div class="form-card">
            <h3 style="margin-top:0;">Add New Doctor</h3>
            <form method="POST" action="manage-doctors.php">
                <input type="hidden" name="action_add" value="1">
                <div class="form-group">
                    <label>Doctor Full Name</label>
                    <input type="text" name="d_name" required placeholder="Dr. Jane Smith">
                </div>
                <div class="form-group">
                    <label>Specialty</label>
                    <input type="text" name="d_specialty" required placeholder="e.g. Cardiology">
                </div>
                <div class="form-group">
                    <label>Phone Number</label>
                    <input type="text" name="d_phone" required placeholder="+1-555-0199">
                </div>
                <button type="submit" class="btn btn-primary">Add Doctor</button>
            </form>
        </div>

        <!-- Doctors Table -->
        <div class="table-card">
            <h3 style="margin-top:0;">Registered Doctors</h3>
            <table>
                <thead>
                    <tr>
                        <th>Doctor Name</th>
                        <th>Specialty</th>
                        <th>Phone</th>
                        <th>Action</th>
                    </tr>
                </thead>
                <tbody>
                    <?php if (empty($doctors)): ?>
                        <tr><td colspan="4" style="text-align:center;">No doctors registered yet.</td></tr>
                    <?php else: ?>
                        <?php foreach ($doctors as $d): ?>
                            <tr>
                                <td><strong><?= htmlspecialchars($d['D_Name']) ?></strong></td>
                                <td><span class="badge"><?= htmlspecialchars($d['D_specialty']) ?></span></td>
                                <td><?= htmlspecialchars($d['D_Phone']) ?></td>
                                <td>
                                    <a href="manage-doctors.php?delete_id=<?= $d['D_ID'] ?>" class="btn btn-danger" onclick="return confirm('Remove doctor?');">Delete</a>
                                </td>
                            </tr>
                        <?php endforeach; ?>
                    <?php endif; ?>
                </tbody>
            </table>
        </div>
    </div>
</div>

</body>
</html>