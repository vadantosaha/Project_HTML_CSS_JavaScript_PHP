
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Manage Beds</title>
    <style>
        body { font-family: Arial, sans-serif; margin: 0; background: #f4f6f9; }
        .navbar { background: #007bff; padding: 15px; color: white; display: flex; justify-content: space-between; }
        .navbar a { color: white; text-decoration: none; margin-left: 15px; }
        .container { max-width: 900px; margin: 30px auto; padding: 20px; background: white; border-radius: 8px; box-shadow: 0 0 10px rgba(0,0,0,0.1); }
        .form-group { margin-bottom: 12px; display: inline-block; margin-right: 10px; }
        .form-group input, .form-group select { padding: 8px; border: 1px solid #ccc; border-radius: 4px; }
        .btn { padding: 8px 15px; background: #007bff; color: white; border: none; border-radius: 4px; cursor: pointer; }
        .btn-danger { background: #dc3545; }
        table { width: 100%; border-collapse: collapse; margin-top: 20px; }
        th, td { border: 1px solid #ddd; padding: 10px; text-align: left; }
        th { background: #f2f2f2; }
        .alert { padding: 10px; border-radius: 4px; margin-bottom: 15px; }
        .alert-success { background: #d4edda; color: #155724; }
        .alert-error { background: #f8d7da; color: #721c24; }
    </style>
</head>
<body>

<div class="navbar">
    <strong>Hospital Dashboard - Manage Beds</strong>
    <div>
        <a href="hospital-dashboard.php">Dashboard</a>
        <a href="logout.php">Logout</a>
    </div>
</div>

<div class="container">
    <h2>Manage Hospital Beds</h2>

    <?php if ($message): ?><div class="alert alert-success"><?= htmlspecialchars($message) ?></div><?php endif; ?>
    <?php if ($error): ?><div class="alert alert-error"><?= htmlspecialchars($error) ?></div><?php endif; ?>

    <h3>Add New Bed</h3>
    <form method="POST" action="manage-beds.php">
        <div class="form-group">
            <input type="text" name="bed_number" placeholder="Bed Number (e.g. B-101)" required>
        </div>
        <div class="form-group">
            <select name="bed_type">
                <option value="General">General</option>
                <option value="ICU">ICU</option>
                <option value="CCU">CCU</option>
                <option value="Cabin">Cabin</option>
            </select>
        </div>
        <div class="form-group">
            <input type="number" step="0.01" name="bed_price" placeholder="Price per day" required>
        </div>
        <button type="submit" name="add_bed" class="btn">Add Bed</button>
    </form>

    <hr style="margin-top: 25px;">

    <h3>Existing Beds</h3>
    <table>
        <thead>
            <tr>
                <th>Bed #</th>
                <th>Type</th>
                <th>Price (Tk)</th>
                <th>Status</th>
                <th>Action</th>
            </tr>
        </thead>
        <tbody>
            <?php if (empty($beds)): ?>
                <tr><td colspan="5">No beds registered yet.</td></tr>
            <?php else: ?>
                <?php foreach ($beds as $b): ?>
                    <tr>
                        <td><?= htmlspecialchars($b['B_Number']) ?></td>
                        <td><?= htmlspecialchars($b['B_Type']) ?></td>
                        <td><?= number_format($b['B_Price'], 2) ?></td>
                        <td><strong><?= htmlspecialchars($b['B_Status']) ?></strong></td>
                        <td>
                            <a href="manage-beds.php?delete=<?= $b['B_ID'] ?>" class="btn btn-danger" onclick="return confirm('Delete this bed?');">Delete</a>
                        </td>
                    </tr>
                <?php endforeach; ?>
            <?php endif; ?>
        </tbody>
    </table>
</div>

</body>
</html>