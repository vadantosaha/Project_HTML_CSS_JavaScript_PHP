
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Doctor Directory</title>
    <style>
    body { font-family: Arial, sans-serif; margin: 0; background: #f4f6f9; }
    .navbar { background: #007bff; padding: 15px; color: white; display: flex; justify-content: space-between; }
    .navbar a { color: white; text-decoration: none; margin-left: 15px; }
    .container { max-width: 1000px; margin: 20px auto; padding: 0 15px; }
    .search-card { background: white; padding: 20px; border-radius: 8px; box-shadow: 0 0 10px rgba(0,0,0,0.1); margin-bottom: 20px; }
    
    /* Updated for baseline button alignment */
    .filter-grid { display: flex; gap: 10px; flex-wrap: wrap; align-items: flex-end; }
    .filter-item { flex: 1; min-width: 180px; display: flex; flex-direction: column; }
    .filter-item label { display: block; margin-bottom: 5px; font-weight: bold; }
    .filter-item input, .filter-item select { width: 100%; padding: 8px; box-sizing: border-box; height: 38px; border: 1px solid #ccc; border-radius: 4px; }
    
    .btn { padding: 8px 12px; color: white; border: none; cursor: pointer; border-radius: 4px; text-decoration: none; font-size: 13px; display: inline-block; height: 38px; box-sizing: border-box; }
    .btn-primary { background: #007bff; }
    .btn-outline { background: transparent; color: #007bff; border: 1px solid #007bff; height: auto; }
    .btn-block { width: 100%; margin-top: 0; }
    
    .doctor-grid { display: grid; grid-template-columns: repeat(auto-fill, minmax(280px, 1fr)); gap: 20px; }
    .doctor-card { background: white; border-radius: 8px; padding: 15px; box-shadow: 0 0 8px rgba(0,0,0,0.08); display: flex; flex-direction: column; justify-content: space-between; }
    .doc-header { border-bottom: 1px solid #eee; padding-bottom: 8px; margin-bottom: 10px; }
    .badge { background: #17a2b8; color: white; padding: 3px 8px; border-radius: 4px; font-size: 11px; font-weight: bold; }
    .alert { padding: 15px; background: #fff3cd; color: #856404; border-radius: 4px; }
    .doc-footer { margin-top: 15px; display: flex; gap: 8px; }
</style>
</head>
<body>

<!-- Integrated Navbar -->
<div class="navbar">
    <strong>Bed Management System</strong>
    <div>
        <a href="home.php">Home</a>
        <?php if (isset($_SESSION['user_name'])): ?>
            <a href="logout.php">Logout</a>
        <?php else: ?>
            <a href="login.php">Login</a>
        <?php endif; ?>
    </div>
</div>

<div class="container">
    <h2>Doctor Directory</h2>

    <!-- Search Form -->
    <div class="search-card">
        <form method="GET" action="doctor-details.php">
            <div class="filter-grid">
                <div class="filter-item">
                    <label>Doctor Name</label>
                    <input type="text" name="search" value="<?= htmlspecialchars($searchDoc) ?>" placeholder="e.g. Dr. Sarah">
                </div>
                <div class="filter-item">
                    <label>Specialty</label>
                    <select name="specialty">
                        <option value="">All Specialties</option>
                        <?php foreach ($specialties as $sp): ?>
                            <option value="<?= htmlspecialchars($sp['D_specialty']) ?>" <?= ($searchSpec === $sp['D_specialty']) ? 'selected' : '' ?>>
                                <?= htmlspecialchars($sp['D_specialty']) ?>
                            </option>
                        <?php endforeach; ?>
                    </select>
                </div>
                <div class="filter-item">
                    <label>Hospital</label>
                    <select name="hospital">
                        <option value="0">All Hospitals</option>
                        <?php foreach ($hospitalsList as $hl): ?>
                            <option value="<?= $hl['H_ID'] ?>" <?= ($searchHosp === (int)$hl['H_ID']) ? 'selected' : '' ?>>
                                <?= htmlspecialchars($hl['H_Name']) ?>
                            </option>
                        <?php endforeach; ?>
                    </select>
                </div>
                <div class="filter-item">
                    <button type="submit" class="btn btn-primary btn-block">Search Doctors</button>
                </div>
            </div>
        </form>
    </div>

    <!-- Doctor Cards -->
    <div class="doctor-grid">
        <?php if (empty($doctors)): ?>
            <div class="alert" style="grid-column: 1 / -1;">No doctors found matching your criteria.</div>
        <?php else: ?>
            <?php foreach ($doctors as $doc): ?>
                <div class="doctor-card">
                    <div>
                        <div class="doc-header">
                            <h3 style="margin:0 0 5px 0;"> <?= htmlspecialchars($doc['D_Name']) ?></h3>
                            <span class="badge"><?= htmlspecialchars($doc['D_specialty']) ?></span>
                        </div>
                        <p> <strong>Hospital:</strong> <?= htmlspecialchars($doc['H_Name']) ?></p>
                        <p> <strong>Location:</strong> <?= htmlspecialchars($doc['H_Address']) ?></p>
                        <p> <strong>Phone:</strong> <?= htmlspecialchars($doc['D_Phone']) ?></p>
                    </div>
                    <div class="doc-footer">
                        <a href="home.php?id=<?= $doc['H_ID'] ?>" class="btn btn-outline">View Hospital</a>
                        <?php if ($isPatient): ?>
                            <a href="admission.php?doctor_id=<?= $doc['D_ID'] ?>" class="btn btn-primary">Request Admission</a>
                        <?php else: ?>
                            <a href="login.php" class="btn btn-primary" onclick="alert('Please login as a patient to continue.');">Request Admission</a>
                        <?php endif; ?>
                    </div>
                </div>
            <?php endforeach; ?>
        <?php endif; ?>
    </div>
</div>

</body>
</html>