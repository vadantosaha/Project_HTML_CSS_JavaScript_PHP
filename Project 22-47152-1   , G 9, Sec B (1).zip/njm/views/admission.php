<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<title>Book Hospital Bed & Admission</title>
<style>
body {
    font-family: Arial, sans-serif;
    margin: 0;
    background: #f4f6f9;
}
.navbar {
    background: #007bff;
    padding: 15px;
    color: white;
    display: flex;
    justify-content: space-between;
}

.navbar a {
    color: white;
    text-decoration: none;
    margin-left: 15px;
}
.container {
    max-width: 700px;
    margin: 30px auto;
    padding: 20px;
}

.section {
    background: white;
    padding: 20px;
    margin-bottom: 20px;
    border-radius: 8px;
    box-shadow: 0 0 10px rgba(0,0,0,.08);
}

.form-group {
    margin-bottom: 15px;
}

.form-group label {
    display: block;
    margin-bottom: 5px;
    font-weight: bold;
}

.form-group select,
.form-group input,
.form-group textarea {
    width: 100%;
    padding: 9px;
    box-sizing: border-box;
    border: 1px solid #ccc;
    border-radius: 4px;
}

.btn {
    padding: 12px;
    background: #28a745;
    color: white;
    border: 0;
    cursor: pointer;
    border-radius: 4px;
    width: 100%;
    font-size: 16px;
}

.alert {
    padding: 10px;
    background: #f8d7da;
    color: #721c24;
    border-radius: 4px;
    margin-bottom: 15px;
}

/* MAP */
.map {
    margin-top: 20px;
}

.map iframe {
    width: 100%;
    height: 400px;
    border: 0;
    border-radius: 8px;
}

</style>

</head>

<body>

<div class="navbar">

    <strong>Bed Management System</strong>

    <div>
        <a href="home.php">Home</a>
        <a href="patient-dashboard.php">Dashboard</a>
        <a href="notifications.php">Notifications</a>
        <a href="logout.php">Logout</a>
    </div>

</div>
<div class="container">

<div class="section">

<h2>Book Hospital Bed & Admission</h2>

<?php if ($error): ?>

<div class="alert">
    <?= htmlspecialchars($error) ?>
</div>

<?php endif; ?>


<!-- Hospital -->

<div class="form-group">

<label>1. Select Hospital</label>

<select
    name="hospital_select"
    required
    onchange="location.href='admission.php?hospital_id=' + this.value;"
>

<option value="">-- Choose Hospital --</option>

<?php foreach ($hospitals as $h): ?>

<option
    value="<?= $h['H_ID'] ?>"
    <?= ($selectedHospitalId == $h['H_ID']) ? 'selected' : '' ?>
>

<?= htmlspecialchars($h['H_Name']) ?>

</option>

<?php endforeach; ?>

</select>

</div>


<?php if ($hospital): ?>

<!-- Hospital Details -->

<div class="section">

<h3><?= htmlspecialchars($hospital['H_Name']) ?></h3>

<p>
<strong>Type:</strong>
<?= htmlspecialchars($hospital['H_Type']) ?>
</p>

<p>
<strong>Address:</strong>
<?= htmlspecialchars($hospital['H_Address']) ?>
</p>

<p>
<strong>Phone:</strong>
<?= htmlspecialchars($hospital['H_Phone']) ?>
</p>

<p>
<strong>Details:</strong>
<?= htmlspecialchars($hospital['H_Details']) ?>
</p>


<!-- MAP FROM H_Address -->

<div class="map">

<h3>Hospital Location</h3>

<iframe
src="https://www.google.com/maps?q=<?= urlencode($hospital['H_Address']) ?>&output=embed"
loading="lazy"
allowfullscreen>
</iframe>

</div>

</div>

<?php endif; ?>


<!-- ADMISSION FORM -->

<form
method="POST"
action="admission.php<?= $selectedHospitalId ? '?hospital_id=' . $selectedHospitalId : '' ?>"
>


<div class="form-group">

<label>2. Select Attending Doctor</label>

<select name="doctor_id" required>

<option value="">-- Choose Doctor --</option>

<?php foreach ($doctors as $d): ?>

<option
value="<?= $d['D_ID'] ?>"
<?= ($preDoctorId == $d['D_ID']) ? 'selected' : '' ?>
>

<?= htmlspecialchars($d['D_Name']) ?>
(<?= htmlspecialchars($d['D_specialty']) ?>)

</option>

<?php endforeach; ?>

</select>

</div>


<div class="form-group">

<label>3. Select Available Bed</label>

<select name="bed_id" required>

<option value="">-- Choose Available Bed --</option>

<?php foreach ($beds as $b): ?>

<option
value="<?= $b['B_ID'] ?>"
<?= ($preBedId == $b['B_ID']) ? 'selected' : '' ?>
>

Bed #<?= htmlspecialchars($b['B_Number']) ?>
-
<?= htmlspecialchars($b['B_Type']) ?>
-
$<?= number_format($b['B_Price'], 2) ?>

</option>

<?php endforeach; ?>

</select>

</div>


<div class="form-group">

<label>4. Admission Date</label>

<input
type="date"
name="admission_date"
required
min="<?= date('Y-m-d') ?>"
value="<?= date('Y-m-d') ?>"
>

</div>
<div class="form-group">

<label>5. Medical Details / Reason</label>

<textarea
name="admission_details"
rows="4"
placeholder="Describe symptoms or diagnosis..."
></textarea>
</div>
<input
type="hidden"
name="hospital_id"
value="<?= $selectedHospitalId ?>"
>
<button type="submit" class="btn">
Submit & Proceed to Payment
</button>
</form>
</div>
</div>
</body>
</html>