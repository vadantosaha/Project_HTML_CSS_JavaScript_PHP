

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Admission Payment Checkout</title>
    <style>
        * { box-sizing: border-box; }
        body { font-family: Arial, sans-serif; margin: 0; background: #f4f6f9; }
        .navbar { background: #007bff; padding: 15px; color: white; display: flex; justify-content: space-between; align-items: center; }
        .navbar a { color: white; text-decoration: none; margin-left: 15px; }
        .container { max-width: 600px; margin: 30px auto; padding: 20px; background: white; border-radius: 8px; box-shadow: 0 0 10px rgba(0,0,0,0.1); }
        h2 { margin-top: 0; }
        .summary-box { background: #f8f9fa; border: 1px solid #e9ecef; padding: 15px; border-radius: 6px; margin-bottom: 20px; }
        .summary-row { display: flex; justify-content: space-between; padding: 8px 0; border-bottom: 1px dashed #ddd; font-size: 14px; }
        .summary-row.total { border-bottom: none; font-size: 17px; font-weight: bold; color: #28a745; margin-top: 5px; }
        .form-group { margin-bottom: 15px; }
        label { display: block; margin-bottom: 6px; font-weight: bold; }
        input, select, textarea { width: 100%; padding: 10px; border: 1px solid #ccc; border-radius: 4px; font-size: 14px; }
        input:focus, select:focus, textarea:focus { border-color: #007bff; outline: none; }
        .payment-details { display: none; background: #f8f9fa; border: 1px solid #ddd; padding: 15px; border-radius: 6px; margin-top: 15px; margin-bottom: 15px; }
        .payment-details h3 { margin-top: 0; font-size: 17px; color: #007bff; }
        .field { margin-bottom: 12px; }
        .cash-notice { color: red; font-weight: bold; background: #fff3f3; padding: 12px; border-radius: 4px; }
        .simulated-box { background: #e2e3e5; padding: 10px; border-radius: 4px; font-size: 12px; margin-bottom: 15px; text-align: center; }
        .btn { padding: 11px 15px; color: white; border: none; cursor: pointer; border-radius: 4px; width: 100%; font-size: 16px; text-align: center; text-decoration: none; display: block; margin-top: 10px; }
        .btn-success { background: #28a745; }
        .btn-success:hover { background: #218838; }
        .btn-primary { background: #007bff; }
        .btn-info { background: #17a2b8; }
        .btn-info:hover { background: #138496; }
        .alert { padding: 12px; border-radius: 4px; margin-bottom: 15px; }
        .alert-danger { background: #f8d7da; color: #721c24; }
        .alert-success { background: #d4edda; color: #155724; }
        .details-box { margin-top: 20px; }
        textarea { resize: none; background: #f8f9fa; }
        @media (max-width: 650px) {
            .container { margin: 15px; }
            .navbar { flex-direction: column; gap: 10px; }
            .navbar a { margin-left: 5px; }
        }
    </style>
</head>
<body>

<div class="navbar">
    <strong>Bed Management System</strong>
    <div>
        <a href="home.php">Home</a>
        <a href="patient-dashboard.php">Dashboard</a>
        <a href="logout.php">Logout</a>
    </div>
</div>

<div class="container">
    <h2>Payment Checkout</h2>
    <p><small>Complete bed booking transaction for Admission #A<?= htmlspecialchars($adm['A_ID']) ?></small></p>

    <?php if ($error): ?>
        <div class="alert alert-danger"><?= htmlspecialchars($error) ?></div>
    <?php endif; ?>

    <!-- Admission Summary -->
    <div class="summary-box">
        <div class="summary-row">
            <span>Hospital:</span>
            <strong><?= htmlspecialchars($adm['H_Name']) ?></strong>
        </div>
        <div class="summary-row">
            <span>Doctor:</span>
            <strong><?= htmlspecialchars($adm['D_Name']) ?></strong>
        </div>
        <div class="summary-row">
            <span>Bed Info:</span>
            <strong>Bed #<?= htmlspecialchars($adm['B_Number']) ?> (<?= htmlspecialchars($adm['B_Type']) ?>)</strong>
        </div>
        <div class="summary-row">
            <span>Admission Date:</span>
            <strong><?= htmlspecialchars($adm['A_Date']) ?></strong>
        </div>
        <div class="summary-row total">
            <span>Total Payable:</span>
            <strong>Tk<?= number_format($adm['A_Amount'], 2) ?></strong>
        </div>
    </div>

    <?php if ($existingPayment): ?>
        <div class="alert alert-success">
             Payment completed via <strong><?= htmlspecialchars($existingPayment['PA_Method']) ?></strong> on <?= htmlspecialchars($existingPayment['PA_Date']) ?>.
        </div>
        <a href="patient-dashboard.php" class="btn btn-primary">Return to Dashboard</a>
    <?php else: ?>
        <form method="POST" action="payment.php?admission_id=<?= $aID ?>" onsubmit="return validatePayment();">
            <div class="form-group">
                <label for="paymentMethod">Select Payment Method:</label>
                <select id="paymentMethod" name="pay_method" onchange="togglePaymentFields()" required>
                    <option value="">-- Select Method --</option>
                    <option value="creditCard">Credit Card</option>
                    <option value="mobileBanking">Mobile Banking</option>
                    <option value="cashOnPlace">Cash on Place</option>
                </select>
            </div>

            <!-- Credit Card -->
            <div id="creditCardDetails" class="payment-details">
                <h3>Credit Card Details</h3>
                <div class="field">
                    <label for="cardName">Cardholder Name:</label>
                    <input type="text" id="cardName" name="card_name" placeholder="Enter cardholder name">
                </div>
                <div class="field">
                    <label for="cardNumber">Card Number:</label>
                    <input type="text" id="cardNumber" name="card_number" placeholder="Enter card number" maxlength="19">
                </div>
                <div class="field">
                    <label for="cardExpiry">Expiry Date:</label>
                    <input type="text" id="cardExpiry" name="card_expiry" placeholder="MM/YY" maxlength="5">
                </div>
                <div class="field">
                    <label for="cardCVV">CVV:</label>
                    <input type="password" id="cardCVV" name="card_cvv" placeholder="Enter CVV" maxlength="4">
                </div>
            </div>

            <!-- Mobile Banking -->
            <div id="mobileBankingDetails" class="payment-details">
                <h3>Mobile Banking Details</h3>
                <div class="field">
                    <label for="mbProvider">Provider:</label>
                    <select id="mbProvider" name="mb_provider">
                        <option value="bKash">bKash</option>
                        <option value="Nagad">Nagad</option>
                    </select>
                </div>
                <div class="field">
                    <label for="mbNumber">Mobile Number:</label>
                    <input type="text" id="mbNumber" name="mb_number" placeholder="Enter mobile number">
                </div>
                <div class="field">
                    <label for="mbTrxId">Transaction ID:</label>
                    <input type="text" id="mbTrxId" name="mb_trx_id" placeholder="Enter transaction ID">
                </div>
            </div>

            <!-- Cash -->
            <div id="cashDetails" class="payment-details">
                <h3>Cash Payment</h3>
                <div class="cash-notice">Notice: You will receive a call from the hospital in 5 minutes.</div>
            </div>

            <div class="simulated-box">
                <em>Sandbox Mode: Clicking Confirm & Pay completes the payment simulation.</em>
            </div>

            <button type="button" class="btn btn-info" onclick="showDetails()">Show Details</button>

            <div class="details-box">
                <label for="detailsBox">Full Details:</label>
                <textarea id="detailsBox" rows="6" readonly placeholder="Details will appear here..."></textarea>
            </div>

            <button type="submit" class="btn btn-success">Confirm & Pay Tk<?= number_format($adm['A_Amount'], 2) ?></button>
        </form>
    <?php endif; ?>
</div>

<script>
function togglePaymentFields() {
    var method = document.getElementById("paymentMethod").value;
    document.getElementById("creditCardDetails").style.display = (method === "creditCard") ? "block" : "none";
    document.getElementById("mobileBankingDetails").style.display = (method === "mobileBanking") ? "block" : "none";
    document.getElementById("cashDetails").style.display = (method === "cashOnPlace") ? "block" : "none";
}

function showDetails() {
    var method = document.getElementById("paymentMethod").value;
    var output = "";

    if (method === "creditCard") {
        var cardName = document.getElementById("cardName").value;
        var cardNumber = document.getElementById("cardNumber").value;
        var cardExpiry = document.getElementById("cardExpiry").value;
        output = "Payment Method: Credit Card\nCardholder Name: " + cardName + "\nCard Number: " + cardNumber + "\nExpiry Date: " + cardExpiry;
    } else if (method === "mobileBanking") {
        var provider = document.getElementById("mbProvider").value;
        var mbNumber = document.getElementById("mbNumber").value;
        var mbTrxId = document.getElementById("mbTrxId").value;
        output = "Payment Method: Mobile Banking\nProvider: " + provider + "\nMobile Number: " + mbNumber + "\nTransaction ID: " + mbTrxId;
    } else if (method === "cashOnPlace") {
        output = "Payment Method: Cash on Place\nNotice: You will receive a call from the hospital in 5 minutes.";
    } else {
        output = "Please select a payment method and fill in the details.";
    }
    document.getElementById("detailsBox").value = output;
}

function validatePayment() {
    var method = document.getElementById("paymentMethod").value;
    if (method === "") {
        alert("Please select a payment method.");
        return false;
    }
    if (method === "creditCard") {
        if (!document.getElementById("cardName").value.trim() || !document.getElementById("cardNumber").value.trim() || !document.getElementById("cardExpiry").value.trim() || !document.getElementById("cardCVV").value.trim()) {
            alert("Please fill in all credit card details.");
            return false;
        }
    }
    if (method === "mobileBanking") {
        if (!document.getElementById("mbNumber").value.trim() || !document.getElementById("mbTrxId").value.trim()) {
            alert("Please enter mobile number and transaction ID.");
            return false;
        }
    }
    return true;
}
</script>
</body>
</html>