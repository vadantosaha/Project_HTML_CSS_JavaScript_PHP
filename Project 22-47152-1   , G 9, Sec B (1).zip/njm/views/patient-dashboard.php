
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Patient Dashboard</title>
    <style>
        body { font-family: Arial, sans-serif; margin: 0; background: #f4f6f9; }
        .navbar { background: #007bff; padding: 15px; color: white; display: flex; justify-content: space-between; }
        .navbar a { color: white; text-decoration: none; margin-left: 15px; }
        .container { max-width: 1100px; margin: 30px auto; padding: 20px; background: white; border-radius: 8px; box-shadow: 0 0 10px rgba(0,0,0,0.1); }
        .profile-card { background: #eef5ff; border: 1px solid #b8daff; padding: 15px; border-radius: 6px; margin-bottom: 25px; }
        .profile-card h3 { margin-top: 0; color: #004085; display: flex; justify-content: space-between; align-items: center; }
        .grid-3 { display: flex; gap: 20px; flex-wrap: wrap; }
        .grid-3 p { margin: 5px 0; font-size: 14px; }
        .header-bar { display: flex; justify-content: space-between; align-items: center; margin-bottom: 15px; }
        .btn { padding: 6px 12px; color: white; border: none; cursor: pointer; border-radius: 4px; text-decoration: none; font-size: 13px; display: inline-block; }
        .btn-primary { background: #007bff; }
        .btn-warning { background: #ffc107; color: #212529; font-weight: bold; }
        .btn-danger { background: #dc3545; }
        .btn-secondary { background: #6c757d; }
        table { width: 100%; border-collapse: collapse; margin-top: 10px; }
        th, td { border: 1px solid #dee2e6; padding: 10px; text-align: left; font-size: 13px; vertical-align: top; }
        th { background: #f8f9fa; }
        .badge { padding: 4px 8px; border-radius: 4px; font-size: 12px; font-weight: bold; display: inline-block; }
        .status-pending { background: #fff3cd; color: #856404; }
        .status-approved { background: #d4edda; color: #155724; }
        .status-rejected { background: #f8d7da; color: #721c24; }
        .tag-success { background: #28a745; color: white; }
        .details-box-text { font-size: 12px; line-height: 1.4; color: #333; }
    </style>
</head>
<body>

<div class="navbar">
    <strong>Bed Management System</strong>
    <div>
        <a href="home.php">Home</a>
        <a href="doctor-details.php">Find Doctors</a>
        <a href="notifications.php">Notifications</a>
        <a href="logout.php">Logout</a>
    </div>
</div>

<div class="container">
    <h2>Patient Control Center</h2>

    <div class="profile-card">
        <h3>
            <span>Patient Profile: <?= htmlspecialchars($patient['P_Name'] ?? 'N/A') ?></span>
            <div>
                <a href="edit-profile.php" class="btn btn-secondary"> Edit Details / Reset Password</a>
            </div>
        </h3>
        <div class="grid-3">
            <p><strong>Username:</strong> <?= htmlspecialchars($patient['P_Username'] ?? 'N/A') ?></p>
            <p><strong>Phone:</strong> <?= htmlspecialchars($patient['P_Phone'] ?? 'N/A') ?></p>
            <p><strong>Address:</strong> <?= htmlspecialchars($patient['P_Address'] ?? 'N/A') ?></p>
        </div>
    </div>

    <div class="header-bar">
        <h3 style="margin: 0;">My Admission History & Status</h3>
        <a href="admission.php" class="btn btn-primary">+ New Admission Request</a>
    </div>

    <table>
        <thead>
            <tr>
                <th>Admission #</th>
                <th>Hospital</th>
                <th>Doctor</th>
                <th>Bed Info</th>
                <th>Date</th>
                <th>Amount</th>
                <th>Status</th>
                <th>Payment Details</th>
                <th>Action</th>
            </tr>
        </thead>
        <tbody>
            <?php if (empty($admissions)): ?>
                <tr><td colspan="9" style="text-align: center;">No admission requests found.</td></tr>
            <?php else: ?>
                <?php foreach ($admissions as $adm): ?>
                    <tr>
                        <td><strong>#A<?= $adm['A_ID'] ?></strong></td>
                        <td><?= htmlspecialchars($adm['H_Name']) ?></td>
                        <td><?= htmlspecialchars($adm['D_Name']) ?></td>
                        <td>Bed #<?= htmlspecialchars($adm['B_Number']) ?> (<?= htmlspecialchars($adm['B_Type']) ?>)</td>
                        <td><?= htmlspecialchars($adm['A_Date']) ?></td>
                        <td>Tk<?= number_format($adm['A_Amount'], 2) ?></td>
                        <td>
                            <span class="badge status-<?= strtolower($adm['A_Status']) ?>">
                                <?= htmlspecialchars($adm['A_Status']) ?>
                            </span>
                        </td>
                        <td>
                            <?php if (!empty($adm['A_Pament_Details'])): ?>
                                <div class="details-box-text">
                                    <?= nl2br(htmlspecialchars($adm['A_Pament_Details'])) ?>
                                </div>
                            <?php elseif (!empty($adm['PA_Method'])): ?>
                                <?= htmlspecialchars($adm['PA_Method']) ?>
                            <?php else: ?>
                                N/A
                            <?php endif; ?>
                        </td>
                        <td>
                            <?php if (($adm['PA_Status'] ?? '') === 'Paid'): ?>
                                <span class="badge tag-success">Paid</span>
                            <?php else: ?>
                                <a href="payment.php?admission_id=<?= $adm['A_ID'] ?>" class="btn btn-warning">Pay Now</a>
                            <?php endif; ?>
                            
                            <?php if ($adm['A_Status'] === 'Pending'): ?>
                                <a href="patient-dashboard.php?cancel_id=<?= $adm['A_ID'] ?>" class="btn btn-danger" onclick="return confirm('Cancel request?');">Cancel</a>
                            <?php endif; ?>
                        </td>
                    </tr>
                <?php endforeach; ?>
            <?php endif; ?>
        </tbody>
    </table>
</div>

</body>
</html>