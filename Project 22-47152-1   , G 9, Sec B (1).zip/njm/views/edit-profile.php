
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Edit Profile & Settings</title>
    <style>
        body { font-family: Arial, sans-serif; margin: 0; background: #f4f6f9; }
        .navbar { background: #007bff; padding: 15px; color: white; display: flex; justify-content: space-between; }
        .navbar a { color: white; text-decoration: none; margin-left: 15px; }
        .container { max-width: 650px; margin: 30px auto; padding: 20px; background: white; border-radius: 8px; box-shadow: 0 0 10px rgba(0,0,0,0.1); }
        .form-section { background: #f8f9fa; border: 1px solid #dee2e6; padding: 15px; border-radius: 6px; margin-bottom: 20px; }
        .form-group { margin-bottom: 12px; }
        .form-group label { display: block; margin-bottom: 5px; font-weight: bold; font-size: 14px; }
        .form-group input, .form-group textarea { width: 100%; padding: 8px; box-sizing: border-box; border: 1px solid #ccc; border-radius: 4px; }
        .btn { padding: 8px 14px; color: white; border: none; cursor: pointer; border-radius: 4px; font-size: 14px; font-weight: bold; }
        .btn-primary { background: #007bff; }
        .btn-warning { background: #ffc107; color: #212529; }
        .btn-danger { background: #dc3545; }
        .alert { padding: 10px; border-radius: 4px; margin-bottom: 15px; }
        .alert-success { background: #d4edda; color: #155724; }
        .alert-danger { background: #f8d7da; color: #721c24; }
    </style>
</head>
<body>

<div class="navbar">
    <strong>Bed Management System</strong>
    <div>
        <a href="home.php">Home</a>
        <a href="<?= ($role === 'patient') ? 'patient-dashboard.php' : 'hospital-dashboard.php' ?>">Dashboard</a>
        <a href="logout.php">Logout</a>
    </div>
</div>

<div class="container">
    <h2>Manage Profile & Account Settings</h2>

    <?php if ($message): ?><div class="alert alert-success"><?= htmlspecialchars($message) ?></div><?php endif; ?>
    <?php if ($error): ?><div class="alert alert-danger"><?= htmlspecialchars($error) ?></div><?php endif; ?>

    <!-- Update Profile Details Section -->
    <div class="form-section">
        <h3>Update Profile Details</h3>
        <form method="POST">
            <?php if ($role === 'patient'): ?>
                <div class="form-group">
                    <label>Full Name</label>
                    <input type="text" name="p_name" value="<?= htmlspecialchars($user['P_Name'] ?? '') ?>" required>
                </div>
                <div class="form-group">
                    <label>Phone Number</label>
                    <input type="text" name="p_phone" value="<?= htmlspecialchars($user['P_Phone'] ?? '') ?>" required>
                </div>
                <div class="form-group">
                    <label>Address</label>
                    <input type="text" name="p_address" value="<?= htmlspecialchars($user['P_Address'] ?? '') ?>" required>
                </div>
            <?php else: ?>
                <div class="form-group">
                    <label>Hospital Name</label>
                    <input type="text" name="h_name" value="<?= htmlspecialchars($user['H_Name'] ?? '') ?>" required>
                </div>
                <div class="form-group">
                    <label>Phone Number</label>
                    <input type="text" name="h_phone" value="<?= htmlspecialchars($user['H_Phone'] ?? '') ?>" required>
                </div>
                <div class="form-group">
                    <label>Address</label>
                    <input type="text" name="h_address" value="<?= htmlspecialchars($user['H_Address'] ?? '') ?>" required>
                </div>
                <div class="form-group">
                    <label>Hospital Details</label>
                    <textarea name="h_details" rows="3"><?= htmlspecialchars($user['H_Details'] ?? '') ?></textarea>
                </div>
            <?php endif; ?>
            <button type="submit" name="update_profile" class="btn btn-primary">Update Details</button>
        </form>
    </div>

    <!-- Password Reset Section -->
    <div class="form-section">
        <h3>Reset Password</h3>
        <form method="POST">
            <div class="form-group">
                <label>Current Password</label>
                <input type="password" name="old_password" required placeholder="Enter current password">
            </div>
            <div class="form-group">
                <label>New Password</label>
                <input type="password" name="new_password" required placeholder="Enter new password">
            </div>
            <button type="submit" name="reset_password" class="btn btn-warning">Reset Password</button>
        </form>
    </div>

    <!-- Delete Account Section -->
    <div class="form-section" style="border-color: #f5c6cb; background: #f8d7da;">
        <h3 style="color: #721c24;">Delete Account</h3>
        <p style="font-size: 13px; color: #721c24;">Warning: Deleting your account will permanently wipe your registration and profile record from the system.</p>
        <form method="POST" onsubmit="return confirm('Are you sure you want to permanently delete your account?');">
            <button type="submit" name="delete_account" class="btn btn-danger">Delete Account</button>
        </form>
    </div>
</div>

</body>
</html>