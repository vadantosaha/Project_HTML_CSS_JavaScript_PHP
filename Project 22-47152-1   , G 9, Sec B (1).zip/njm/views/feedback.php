<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Hospital Service Feedback</title>
    <script src="https://cdn.jsdelivr.net/npm/chart.js"></script>
    <style>
        body { font-family: Arial, sans-serif; background: #f3f4f6; padding: 20px; }
        .card { max-width: 600px; margin: auto; background: #fff; padding: 25px; border-radius: 12px; box-shadow: 0 4px 10px rgba(0,0,0,0.05); }
        .title { text-align: center; margin-bottom: 5px; color: #1e3a8a; }
        .sub { text-align: center; color: #6b7280; font-size: 13px; margin-bottom: 20px; }
        .emojis { display: flex; justify-content: center; gap: 10px; margin-bottom: 15px; }
        .emoji { font-size: 28px; cursor: pointer; opacity: 0.5; padding: 8px; border-radius: 50%; }
        .emoji.active { opacity: 1; background: #eff6ff; border: 2px solid #3b82f6; transform: scale(1.1); }
        .form-group { margin-bottom: 12px; }
        .form-group label { display: block; font-size: 12px; font-weight: bold; margin-bottom: 4px; }
        .input { width: 100%; padding: 10px; border: 1px solid #ccc; border-radius: 6px; box-sizing: border-box; }
        .btn { width: 100%; padding: 12px; background: #2563eb; color: white; border: none; border-radius: 6px; font-weight: bold; cursor: pointer; }
        .btn:hover { background: #1d4ed8; }
        table { width: 100%; border-collapse: collapse; margin-top: 10px; font-size: 13px; }
        th, td { border: 1px solid #eee; padding: 8px; text-align: left; }
        th { background: #eff6ff; color: #1e40af; }
        .cookie-box { background: #eff6ff; color: #1d4ed8; padding: 8px 12px; font-size: 12px; border-radius: 6px; margin-bottom: 15px; }
    </style>
</head>
<body>

<div class="card">
    <h2 class="title">How are you feeling?</h2>
    <p class="sub">Your feedback helps us improve our service.</p>

    <!-- Cookie Status Banner -->
    <?php if ($cookieName): ?>
        <div class="cookie-box">Welcome back, <strong><?= htmlspecialchars($cookieName) ?></strong>! (Loaded from Cookie)</div>
    <?php endif; ?>

    <!-- Emoji Selector -->
    <div class="emojis">
        <span class="emoji" onclick="setRating(1, this)">😫</span>
        <span class="emoji" onclick="setRating(2, this)">😔</span>
        <span class="emoji active" onclick="setRating(3, this)">😐</span>
        <span class="emoji" onclick="setRating(4, this)">🙂</span>
        <span class="emoji" onclick="setRating(5, this)">🥰</span>
    </div>

    <!-- Feedback Form -->
    <form id="fbForm" onsubmit="saveData(event)">
        <input type="hidden" id="rating" value="3">
        
        <div class="form-group">
            <label>Name:</label>
            <input type="text" id="patient_name" class="input" value="<?= htmlspecialchars($cookieName) ?>" required>
        </div>

        <div class="form-group">
            <label>Department:</label>
            <select id="department" class="input" required>
                <option value="Emergency">Emergency</option>
                <option value="ICU">ICU</option>
                <option value="General Ward">General Ward</option>
                <option value="OPD">OPD</option>
            </select>
        </div>

        <div class="form-group">
            <label>Comment:</label>
            <textarea id="comments" class="input" rows="3" placeholder="Add a Comment..." required></textarea>
        </div>

        <div class="form-group">
            <label style="font-weight:normal;">
                <input type="checkbox" id="remember" <?= $cookieName ? 'checked' : '' ?>> Remember my name (Cookie)
            </label>
        </div>

        <button type="submit" class="btn">Submit Feedback</button>
    </form>

    <hr style="margin: 25px 0; border: 0; border-top: 1px solid #eee;">

    <!-- Bar Chart Analytics -->
    <h3 style="font-size: 15px;">Department Analytics</h3>
    <canvas id="chart" height="120"></canvas>

    <hr style="margin: 25px 0; border: 0; border-top: 1px solid #eee;">

    <!-- Live Table Search/Filter -->
    <h3 style="font-size: 15px;">Recent Feedbacks</h3>
    <select id="filter" class="input" onchange="loadData()" style="margin-bottom:10px;">
        <option value="">All Departments</option>
        <option value="Emergency">Emergency</option>
        <option value="ICU">ICU</option>
        <option value="General Ward">General Ward</option>
        <option value="OPD">OPD</option>
    </select>

    <table>
        <thead>
            <tr><th>#</th><th>Name</th><th>Dept</th><th>Details</th></tr>
        </thead>
        <tbody id="tableBody"></tbody>
    </table>
</div>

<!-- ---------------------------------------------------------
     JAVASCRIPT LOGIC (AJAX & Chart.js)
---------------------------------------------------------- -->
<script>
let chartInstance = null;

/* 
 * FIX 3: Helper function to escape HTML special characters
 * Prevents XSS attacks when users submit dynamic feedback strings.
 */
function escapeHtml(text) {
    if (!text) return '';
    return text
        .replace(/&/g, "&amp;")
        .replace(/</g, "&lt;")
        .replace(/>/g, "&gt;")
        .replace(/"/g, "&quot;")
        .replace(/'/g, "&#039;");
}

function setRating(val, el) {
    document.querySelectorAll('.emoji').forEach(e => e.classList.remove('active'));
    el.classList.add('active');
    document.getElementById('rating').value = val;
}

// Submit Form (AJAX)
function saveData(e) {
    e.preventDefault();
    let fd = new FormData();
    fd.append('patient_name', document.getElementById('patient_name').value);
    fd.append('rating', document.getElementById('rating').value);
    fd.append('department', document.getElementById('department').value);
    fd.append('comments', document.getElementById('comments').value);
    if(document.getElementById('remember').checked) fd.append('remember_name', '1');

    fetch('feedback.php?action=submit', { method: 'POST', body: fd })
    .then(r => r.json())
    .then(res => {
        if(res.status === 'success') {
            alert('Submitted successfully!');
            document.getElementById('comments').value = '';
            loadData();
        } else {
            alert(res.message || 'Error submitting feedback.');
        }
    })
    .catch(err => console.error('Error:', err));
}

// Fetch Table & Chart Data (AJAX)
function loadData() {
    let dept = document.getElementById('filter').value;
    fetch(`feedback.php?action=fetch&dept=${encodeURIComponent(dept)}`)
    .then(r => r.json())
    .then(res => {
        // Render Table Data using escapeHtml to avoid XSS
        let rows = '';
        res.data.forEach(item => {
            rows += `<tr>
                <td>#${escapeHtml(item.id.toString())}</td>
                <td>${escapeHtml(item.patient_name)}</td>
                <td>${escapeHtml(item.department)}</td>
                <td>${escapeHtml(item.comments)}</td>
            </tr>`;
        });
        document.getElementById('tableBody').innerHTML = rows || '<tr><td colspan="4">No data found</td></tr>';

        // Render Blue Rounded Bar Chart
        if (chartInstance) chartInstance.destroy();
        chartInstance = new Chart(document.getElementById('chart'), {
            type: 'bar',
            data: {
                labels: res.stats.map(s => s.department),
                datasets: [{
                    data: res.stats.map(s => s.total),
                    backgroundColor: '#3b82f6',
                    borderRadius: 6
                }]
            },
            options: { plugins: { legend: { display: false } }, scales: { y: { beginAtZero: true } } }
        });
    })
    .catch(err => console.error('Fetch error:', err));
}

document.addEventListener('DOMContentLoaded', loadData);
</script>

</body>
</html>