
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Process Admissions</title>
    <style>
        body { font-family: Arial, sans-serif; margin: 0; background: #f4f6f9; }
        .navbar { background: #007bff; padding: 15px; color: white; display: flex; justify-content: space-between; }
        .navbar a { color: white; text-decoration: none; margin-left: 15px; }
        .container { max-width: 1100px; margin: 30px auto; padding: 20px; background: white; border-radius: 8px; box-shadow: 0 0 10px rgba(0,0,0,0.1); }
        table { width: 100%; border-collapse: collapse; margin-top: 15px; }
        th, td { border: 1px solid #ddd; padding: 10px; text-align: left; font-size: 13px; vertical-align: top; }
        th { background: #f2f2f2; }
        .btn { padding: 6px 12px; border: none; border-radius: 4px; color: white; text-decoration: none; cursor: pointer; font-size: 13px; display: inline-block; }
        .btn-success { background: #28a745; }
        .btn-danger { background: #dc3545; }
        .badge { padding: 4px 8px; border-radius: 4px; font-size: 12px; font-weight: bold; display: inline-block; }
        .tag-success { background: #28a745; color: white; }
        .tag-warning { background: #ffc107; color: #212529; }
        .alert { padding: 10px; border-radius: 4px; margin-bottom: 15px; }
        .alert-success { background: #d4edda; color: #155724; }
        .alert-error { background: #f8d7da; color: #721c24; }
        .details-box-text { font-size: 12px; line-height: 1.4; margin-bottom: 5px; color: #333; }
    </style>
</head>
<body>

<div class="navbar">
    <strong>Hospital Dashboard</strong>
    <div>
        <a href="hospital-dashboard.php">Dashboard</a>
        <a href="logout.php">Logout</a>
    </div>
</div>

<div class="container">
    <h2>Process Patient Admissions</h2>

    <?php if ($message): ?><div class="alert alert-success"><?= htmlspecialchars($message) ?></div><?php endif; ?>
    <?php if ($error): ?><div class="alert alert-error"><?= htmlspecialchars($error) ?></div><?php endif; ?>

    <table>
        <thead>
            <tr>
                <th>ID</th>
                <th>Patient Name</th>
                <th>Doctor</th>
                <th>Bed #</th>
                <th>Admission Date</th>
                <th>Amount (Tk)</th>
                <th>Status</th>
                <th>Payment Details</th>
                <th>Actions</th>
            </tr>
        </thead>
        <tbody>
            <?php if (empty($admissions)): ?>
                <tr><td colspan="9" style="text-align:center;">No pending or existing admission requests found.</td></tr>
            <?php else: ?>
                <?php foreach ($admissions as $adm): ?>
                    <tr>
                        <td>#A<?= $adm['A_ID'] ?></td>
                        <td><?= htmlspecialchars($adm['P_Name'] ?? 'N/A') ?></td>
                        <td><?= htmlspecialchars($adm['D_Name'] ?? 'N/A') ?></td>
                        <td>Bed #<?= htmlspecialchars($adm['B_Number'] ?? 'N/A') ?></td>
                        <td><?= htmlspecialchars($adm['A_Date']) ?></td>
                        <td>Tk<?= number_format($adm['A_Amount'], 2) ?></td>
                        <td><strong><?= htmlspecialchars($adm['A_Status']) ?></strong></td>
                        <td>
                            <?php if (!empty($adm['A_Pament_Details'])): ?>
                                <div class="details-box-text">
                                    <?= nl2br(htmlspecialchars($adm['A_Pament_Details'])) ?>
                                </div>
                                <span class="badge tag-success"><?= htmlspecialchars($adm['PA_Status'] ?? 'Paid') ?></span>
                            <?php elseif (!empty($adm['PA_Method'])): ?>
                                <?= htmlspecialchars($adm['PA_Method']) ?><br>
                                <span class="badge tag-success"><?= htmlspecialchars($adm['PA_Status']) ?></span>
                            <?php else: ?>
                                <span class="badge tag-warning">Unpaid</span>
                            <?php endif; ?>
                        </td>
                        <td>
                            <?php if ($adm['A_Status'] === 'Pending'): ?>
                                <a href="process-admissions.php?action=approve&admission_id=<?= $adm['A_ID'] ?>" class="btn btn-success" onclick="return confirm('Approve this admission?');">Approve</a>
                                <a href="process-admissions.php?action=reject&admission_id=<?= $adm['A_ID'] ?>" class="btn btn-danger" onclick="return confirm('Reject this admission?');">Reject</a>
                            <?php else: ?>
                                Completed
                            <?php endif; ?>
                        </td>
                    </tr>
                <?php endforeach; ?>
            <?php endif; ?>
        </tbody>
    </table>
</div>

</body>
</html>