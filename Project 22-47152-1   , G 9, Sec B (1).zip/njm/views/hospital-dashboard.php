
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Hospital Management Dashboard</title>
    <style>
        * { box-sizing: border-box; font-family: -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, sans-serif; }
        body { margin: 0; background-color: #f8f9fa; color: #333; }
        
        /* Top Navigation Bar */
        .navbar { background-color: #007bff; padding: 14px 40px; color: white; display: flex; justify-content: space-between; align-items: center; }
        .navbar .brand { font-size: 20px; font-weight: bold; }
        .navbar .nav-links a { color: white; text-decoration: none; margin-left: 20px; font-size: 16px; }
        .navbar .nav-links a:hover { text-decoration: underline; }

        /* Main Container */
        .container { max-width: 1100px; margin: 30px auto; background: white; padding: 30px; border-radius: 6px; box-shadow: 0 1px 3px rgba(0,0,0,0.05); }

        .dashboard-header { display: flex; justify-content: space-between; align-items: flex-start; }
        .dashboard-header h1 { margin: 0 0 5px 0; font-size: 28px; color: #212529; }
        .dashboard-header p { margin: 0; color: #6c757d; font-size: 15px; }

        .btn { padding: 8px 14px; color: white; border: none; cursor: pointer; border-radius: 4px; text-decoration: none; font-size: 14px; display: inline-block; font-weight: bold; }
        .btn-secondary { background: #6c757d; }

        hr { border: 0; border-top: 1px solid #e9ecef; margin: 20px 0 30px 0; }

        /* Metric Cards Grid */
        .stats-grid { display: grid; grid-template-columns: repeat(4, 1fr); gap: 20px; margin-bottom: 30px; }

        .stat-card { background: #f8f9fa; border: 1px solid #e9ecef; border-radius: 6px; padding: 20px 15px; text-align: center; }
        .stat-card .number { font-size: 32px; font-weight: bold; margin-bottom: 8px; }
        .stat-card .label { color: #6c757d; font-size: 14px; }

        .stat-blue { color: #007bff; }
        .stat-green { color: #28a745; }
        .stat-yellow { color: #ffc107; }

        /* Action Buttons Grid */
        .actions-grid { display: grid; grid-template-columns: repeat(4, 1fr); gap: 20px; }
        .action-card { 
            display: flex; 
            flex-direction: column; 
            align-items: center; 
            justify-content: center; 
            background: #ffffff; 
            border: 2px solid #007bff; 
            border-radius: 8px; 
            padding: 25px 15px; 
            text-decoration: none; 
            transition: all 0.2s ease-in-out; 
            min-height: 130px;
        }
        .action-card:hover { background-color: #007bff; }
        .action-card:hover .action-title { color: #ffffff; }
        .action-card .icon { font-size: 28px; margin-bottom: 10px; }
        .action-card .action-title { font-size: 16px; font-weight: bold; color: #007bff; margin: 0; }
    </style>
</head>
<body>

<div class="navbar">
    <div class="brand">Bed Management System</div>
    <div class="nav-links">
        <a href="home.php">Home</a>
        <a href="notifications.php">Notifications</a>
        <a href="logout.php">Logout</a>
    </div>
</div>

<div class="container">
    <div class="dashboard-header">
        <div>
            <h1>Hospital Management Dashboard</h1>
            <p>User Hospital: <strong><?= htmlspecialchars($hName) ?></strong> | Phone: <?= htmlspecialchars($hPhone) ?> | Location: <?= htmlspecialchars($hAddress) ?></p>
        </div>
        <div>
            <a href="edit-profile.php" class="btn btn-secondary">Facility Settings & Password</a>
        </div>
    </div>

    <hr>

    <!-- Stat Display Row -->
    <div class="stats-grid">
        <div class="stat-card">
            <div class="number stat-blue"><?= $totalBeds ?></div>
            <div class="label">Total Registered Beds</div>
        </div>
        <div class="stat-card">
            <div class="number stat-green"><?= $availableBeds ?></div>
            <div class="label">Available Beds</div>
        </div>
        <div class="stat-card">
            <div class="number stat-blue"><?= $totalDoctors ?></div>
            <div class="label">Medical Staff (Doctors)</div>
        </div>
        <div class="stat-card">
            <div class="number stat-yellow"><?= $pendingAdmissions ?></div>
            <div class="label">Pending Admissions</div>
        </div>
    </div>

    <!-- Action Navigation Cards -->
    <div class="actions-grid">
        <a href="manage-doctors.php" class="action-card">
            <div class="icon"></div>
            <h3 class="action-title">Manage Doctors</h3>
        </a>

        <a href="manage-beds.php" class="action-card">
            <div class="icon"></div>
            <h3 class="action-title">Manage Beds</h3>
        </a>

        <a href="process-admissions.php" class="action-card">
            <div class="icon"></div>
            <h3 class="action-title">Process Admissions</h3>
        </a>

        <a href="edit-profile.php" class="action-card">
            <div class="icon"></div>
            <h3 class="action-title">Edit Profile</h3>
        </a>
    </div>
</div>

</body>
</html>