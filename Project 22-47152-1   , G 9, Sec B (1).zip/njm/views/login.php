
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Login - Bed Management System</title>
    <style>
        body { font-family: Arial, sans-serif; margin: 0; background: #f4f6f9; }
        .navbar { background: #007bff; padding: 15px; color: white; display: flex; justify-content: space-between; }
        .navbar a { color: white; text-decoration: none; margin-left: 15px; }
        .card { width: 380px; margin: 50px auto; padding: 25px; background: white; border-radius: 8px; box-shadow: 0 0 10px rgba(0,0,0,0.1); }
        .form-group { margin-bottom: 15px; }
        .form-group label { display: block; margin-bottom: 5px; font-weight: bold; }
        .form-group input[type="text"], .form-group input[type="password"] { width: 100%; padding: 8px; box-sizing: border-box; border: 1px solid #ccc; border-radius: 4px; }
        
        /* Inline Single Row Styling for Radio Buttons */
        .radio-group {
            display: flex;
            align-items: center;
            gap: 15px;
        }
        .radio-group > label {
            margin-bottom: 0;
            font-weight: bold;
        }
        .radio-label {
            display: inline-flex;
            align-items: center;
            gap: 5px;
            font-weight: normal !important;
            cursor: pointer;
        }
        .radio-label input[type="radio"] {
            width: auto;
            margin: 0;
        }

        .btn { width: 100%; padding: 10px; background: #007bff; color: white; border: none; cursor: pointer; border-radius: 4px; font-size: 15px; font-weight: bold; }
        .error { color: #dc3545; background: #f8d7da; border: 1px solid #f5c6cb; padding: 10px; border-radius: 4px; margin-bottom: 15px; font-size: 14px; }
        .auth-footer { text-align: center; margin-top: 15px; font-size: 14px; }
    </style>
</head>
<body>

<div class="navbar">
    <strong>Bed Management System</strong>
    <div>
        <a href="home.php">Home</a>
        <a href="register.php">Register</a>
    </div>
</div>

<div class="card">
    <h3 style="margin-top: 0; text-align: center; font-size: 32px; color: #007bff; text-shadow: 2px 2px 4px rgba(0,0,0,0.2);">Login</h3>

    <?php if ($error): ?>
        <div class="error"><?= htmlspecialchars($error) ?></div>
    <?php endif; ?>

    <form method="POST" action="login.php">
        <div class="form-group radio-group">
            <label>Login As:</label>
            <label class="radio-label">
                <input type="radio" name="role_type" value="patient" checked onclick="toggleFields('patient')"> Patient
            </label>
            <label class="radio-label">
                <input type="radio" name="role_type" value="hospital" onclick="toggleFields('hospital')"> Hospital
            </label>
        </div>

        <div id="patientFields">
            <div class="form-group">
                <label>Patient Username</label>
                <input type="text" name="p_username" placeholder="Enter patient username">
            </div>
        </div>

        <div id="hospitalFields" style="display: none;">
            <div class="form-group">
                <label>Hospital Name</label>
                <input type="text" name="h_name" placeholder="Enter hospital name">
            </div>
        </div>

        <div class="form-group">
            <label>Password</label>
            <input type="password" name="password" required placeholder="Enter password">
        </div>

        <button type="submit" class="btn">Login</button>
    </form>

    <div class="auth-footer">
        Don't have an account? <a href="register.php">Register Here</a>
    </div>
</div>

<script>
function toggleFields(role) {
    document.getElementById('patientFields').style.display = (role === 'patient') ? 'block' : 'none';
    document.getElementById('hospitalFields').style.display = (role === 'hospital') ? 'block' : 'none';
}
</script>

</body>
</html>