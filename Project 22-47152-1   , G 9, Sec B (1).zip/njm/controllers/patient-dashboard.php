<?php
// সেশন শুরু করা হচ্ছে
session_start();

// ডাটাবেস সংযোগ ফাইল যুক্ত করা হচ্ছে ($conn ভেরিয়েবল ইনক্লুড করা হয়েছে)
require_once __DIR__ . "/../models/db.php"; 

// রোগী (Patient) লগইন করা আছে কিনা তা যাচাই করা; না থাকলে লগইন পেজে রিডাইরেক্ট করা হবে
if (!isset($_SESSION['patient_id'])) {
    header("Location: login.php");
    exit();
}

// সেশন থেকে রোগীর আইডি ইনিশিয়ালাইজ করা
$pID = $_SESSION['patient_id'];

// রোগী কোনো পেন্ডিং (Pending) ভর্তি বাতিল করতে চাইলে তা প্রসেস করা (DELETE)
if (isset($_GET['cancel_id'])) {
    $cancelID = intval($_GET['cancel_id']);
    
    // নির্দিষ্ট ভর্তি আইডি এবং রোগী আইডি মিলিয়ে কেবল 'Pending' স্ট্যাটাসের রেকর্ড মুছে ফেলা
    $cStmt = mysqli_prepare($conn, "DELETE FROM admission WHERE A_ID = ? AND P_ID = ? AND A_Status = 'Pending'");
    mysqli_stmt_bind_param($cStmt, "ii", $cancelID, $pID);
    mysqli_stmt_execute($cStmt);
    
    // সফলভাবে ডিলিট করার পর পেশেন্ট ড্যাশবোর্ডে রিডাইরেক্ট করা
    header("Location: patient-dashboard.php");
    exit();
}

// লগইন করা রোগীর ব্যক্তিগত তথ্য ডাটাবেস থেকে তুলে আনা
$pStmt = mysqli_prepare($conn, "SELECT * FROM patient WHERE P_ID = ?");
mysqli_stmt_bind_param($pStmt, "i", $pID);
mysqli_stmt_execute($pStmt);
$patient = mysqli_fetch_assoc(mysqli_stmt_get_result($pStmt));

// রোগীর সকল এডমিশন, ডাক্তার, বেড, হাসপাতাল এবং পেমেন্ট সংক্রান্ত তথ্য একত্রে নিয়ে আসার SQL কোয়েরি (JOIN)
$sql = "SELECT a.*, d.D_Name, b.B_Number, b.B_Type, h.H_Name, p.PA_Status, p.PA_Method
        FROM admission a
        JOIN doctor d ON a.D_ID = d.D_ID
        JOIN bed b ON a.B_ID = b.B_ID
        JOIN hospital h ON b.H_ID = h.H_ID
        LEFT JOIN payment p ON a.A_ID = p.A_ID
        WHERE a.P_ID = ?
        ORDER BY a.A_ID DESC";

// ডাটাবেস থেকে এডমিশনের তথ্য এক্সিকিউট এবং ফেচ করা (নতুন এডমিশন আগে দেখাবে)
$aStmt = mysqli_prepare($conn, $sql);
mysqli_stmt_bind_param($aStmt, "i", $pID);
mysqli_stmt_execute($aStmt);
$admissions = mysqli_fetch_all(mysqli_stmt_get_result($aStmt), MYSQLI_ASSOC);

// পেশেন্ট ড্যাশবোর্ডের ভিউ (UI/HTML) ফাইল যুক্ত করা
require __DIR__ . "/../views/patient-dashboard.php";
?>