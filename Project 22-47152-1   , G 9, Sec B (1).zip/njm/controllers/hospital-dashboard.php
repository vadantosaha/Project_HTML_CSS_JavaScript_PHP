<?php
// সেশন শুরু করা হচ্ছে
session_start();

// ডাটাবেস সংযোগ ফাইল যুক্ত করা হচ্ছে
require_once __DIR__ . "/../models/db.php";

// হাসপাতাল (Hospital) লগইন করা আছে কিনা তা যাচাই করা; না থাকলে লগইন পেজে রিডাইরেক্ট করা হবে
if (!isset($_SESSION['hospital_id'])) {
    header("Location: login.php");
    exit();
}

// সেশন থেকে হাসপাতালের আইডি সংগ্রহ করা
$hID = $_SESSION['hospital_id'];

// হাসপাতালের বিস্তারিত তথ্য (নাম, ফোন, ঠিকানা) ডাটাবেস থেকে তুলে আনা
$hQuery = mysqli_prepare($conn, "SELECT H_Name, H_Phone, H_Address FROM hospital WHERE H_ID = ?");
mysqli_stmt_bind_param($hQuery, "i", $hID);
mysqli_stmt_execute($hQuery);
$hData = mysqli_fetch_assoc(mysqli_stmt_get_result($hQuery));

// তথ্যগুলো ভেরিয়েবলে অ্যাসাইন করা (ডিফল্ট মানসহ)
$hName = $hData['H_Name'] ?? 'Hospital';
$hPhone = $hData['H_Phone'] ?? 'N/A';
$hAddress = $hData['H_Address'] ?? 'N/A';

// ড্যাশবোর্ডের সামারি মেট্রিক্স (Summary Metrics) বা পরিসংখ্যান সংগ্রহ:

// ১. হাসপাতালের মোট বেডের সংখ্যা গণনা করা
$q1 = mysqli_query($conn, "SELECT COUNT(*) as total FROM bed WHERE H_ID = $hID");
$totalBeds = mysqli_fetch_assoc($q1)['total'] ?? 0;

// ২. হাসপাতালের খালি (Available) বেডের সংখ্যা গণনা করা
$q2 = mysqli_query($conn, "SELECT COUNT(*) as avail FROM bed WHERE H_ID = $hID AND B_Status = 'Available'");
$availableBeds = mysqli_fetch_assoc($q2)['avail'] ?? 0;

// ৩. হাসপাতালের মোট ডাক্তারের সংখ্যা গণনা করা
$q3 = mysqli_query($conn, "SELECT COUNT(*) as docs FROM doctor WHERE H_ID = $hID");
$totalDoctors = mysqli_fetch_assoc($q3)['docs'] ?? 0;

// ৪. অপেক্ষমাণ (Pending) অ্যাডমিশন বা ভর্তির অনুরোধের সংখ্যা গণনা করা
$q4 = mysqli_query($conn, "SELECT COUNT(*) as pending FROM admission a JOIN bed b ON a.B_ID = b.B_ID WHERE b.H_ID = $hID AND a.A_Status = 'Pending'");
$pendingAdmissions = mysqli_fetch_assoc($q4)['pending'] ?? 0;

// হাসপাতাল ড্যাশবোর্ডের ভিউ (UI/HTML) ফাইল যুক্ত করা
require __DIR__ . "/../views/hospital-dashboard.php";
?>