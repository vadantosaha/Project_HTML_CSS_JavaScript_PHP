<?php
// সেশন শুরু করা হচ্ছে
session_start();

// ডাটাবেস সংযোগ ফাইল যুক্ত করা হচ্ছে ($conn ভেরিয়েবল ইনক্লুড করা হয়েছে)
require_once __DIR__ . "/../models/db.php"; 

// হাসপাতাল (Hospital) লগইন করা আছে কিনা তা যাচাই করা; না থাকলে লগইন পেজে রিডাইরেক্ট করা হবে
if (!isset($_SESSION['hospital_id'])) {
    header("Location: login.php");
    exit();
}

// সেশন থেকে হাসপাতালের আইডি এবং নোটিফিকেশন মেসেজ ভেরিয়েবল ইনিশিয়ালাইজ করা
$hID = $_SESSION['hospital_id'];
$error = '';
$success = '';

// নতুন ডাক্তার যোগ করার প্রসেসিং (INSERT)
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['action_add'])) {
    $dName  = trim($_POST['d_name'] ?? '');
    $dSpec  = trim($_POST['d_specialty'] ?? '');
    $dPhone = trim($_POST['d_phone'] ?? '');

    // ডাক্তারের সকল তথ্য সঠিকভাবে পূরণ করা হয়েছে কিনা তা যাচাই করা
    if (empty($dName) || empty($dSpec) || empty($dPhone)) {
        $error = "All doctor details are required.";
    } else {
        // ডাটাবেসে ডাক্তারের তথ্য ইনসার্ট করার জন্য Prepared Statement
        $stmt = mysqli_prepare($conn, "INSERT INTO doctor (H_ID, D_Name, D_specialty, D_Phone) VALUES (?, ?, ?, ?)");
        mysqli_stmt_bind_param($stmt, "isss", $hID, $dName, $dSpec, $dPhone);
        
        if (mysqli_stmt_execute($stmt)) {
            $success = "Doctor added successfully.";
        } else {
            $error = "Failed to add doctor.";
        }
    }
}

// ডাক্তার মুছে ফেলার প্রসেসিং (DELETE)
if (isset($_GET['delete_id'])) {
    $delID = intval($_GET['delete_id']);
    
    // নির্দিষ্ট হাসপাতাল এবং ডাক্তার আইডি মিলিয়ে ডাটাবেস থেকে মুছে ফেলা
    $stmt = mysqli_prepare($conn, "DELETE FROM doctor WHERE D_ID = ? AND H_ID = ?");
    mysqli_stmt_bind_param($stmt, "ii", $delID, $hID);
    mysqli_stmt_execute($stmt);
    
    // ফ্ল্যাশ মেসেজ সেট করে পুনরায় পেজে রিডাইরেক্ট করা
    $_SESSION['flash_success'] = "Doctor removed.";
    header("Location: manage-doctors.php");
    exit();
}

// এই হাসপাতালের সকল ডাক্তারের তালিকা ডাটাবেস থেকে তুলে আনা (নামের বর্ণানুক্রম অনুযায়ী)
$dStmt = mysqli_prepare($conn, "SELECT * FROM doctor WHERE H_ID = ? ORDER BY D_Name ASC");
mysqli_stmt_bind_param($dStmt, "i", $hID);
mysqli_stmt_execute($dStmt);
$doctors = mysqli_fetch_all(mysqli_stmt_get_result($dStmt), MYSQLI_ASSOC);

// ডাক্তার ম্যানেজমেন্টের ভিউ (UI/HTML) ফাইল যুক্ত করা
require __DIR__ . "/../views/manage-doctors.php";
?>