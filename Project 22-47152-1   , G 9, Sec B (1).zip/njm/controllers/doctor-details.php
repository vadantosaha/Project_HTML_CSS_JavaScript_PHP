<?php
// সেশন শুরু করা হচ্ছে
session_start();

// ডাটাবেস সংযোগ ফাইল যুক্ত করা হচ্ছে
require_once __DIR__ . "/../models/db.php";

// URL (GET রিকোয়েস্ট) থেকে সার্চ ফিল্টারের মানগুলো নেওয়া এবং স্পেস ফিল্টার করা
$searchDoc = trim($_GET['search'] ?? '');
$searchSpec = trim($_GET['specialty'] ?? '');
$searchHosp = intval($_GET['hospital'] ?? 0);

// ড্রপডাউন ফিল্টারের জন্য ডাটাবেস থেকে সকল স্পেশালিটির (বিশেষজ্ঞতা) অনন্য তালিকা নিয়ে আসা
$specQuery = mysqli_query($conn, "SELECT DISTINCT D_specialty FROM doctor ORDER BY D_specialty ASC");
$specialties = mysqli_fetch_all($specQuery, MYSQLI_ASSOC);

// ড্রপডাউন ফিল্টারের জন্য সকল হাসপাতালের তালিকা নিয়ে আসা
$hospQuery = mysqli_query($conn, "SELECT H_ID, H_Name FROM hospital ORDER BY H_Name ASC");
$hospitalsList = mysqli_fetch_all($hospQuery, MYSQLI_ASSOC);

// ডাইনামিক SQL কুয়েরি তৈরি: ডাক্তার এবং হাসপাতাল টেবিল JOIN করা হচ্ছে
$sql = "SELECT d.*, h.H_Name, h.H_Address 
        FROM doctor d 
        JOIN hospital h ON d.H_ID = h.H_ID 
        WHERE 1=1";
$params = [];
$types = "";

// ডাক্তারের নাম দিয়ে সার্চ ফিল্টার যুক্ত করা
if (!empty($searchDoc)) {
    $sql .= " AND d.D_Name LIKE ?";
    $params[] = "%" . $searchDoc . "%";
    $types .= "s";
}

// স্পেশালিটি (বিশেষজ্ঞতা) দিয়ে ফিল্টার যুক্ত করা
if (!empty($searchSpec)) {
    $sql .= " AND d.D_specialty = ?";
    $params[] = $searchSpec;
    $types .= "s";
}

// নির্দিষ্ট হাসপাতাল দিয়ে ফিল্টার যুক্ত করা
if ($searchHosp > 0) {
    $sql .= " AND d.H_ID = ?";
    $params[] = $searchHosp;
    $types .= "i";
}

// ডাক্তারের নামের বর্ণানুক্রম (A-Z) অনুযায়ী সাজানো
$sql .= " ORDER BY d.D_Name ASC";

// Prepared Statement দিয়ে নিরাপদে SQL কুয়েরি এক্সিকিউট করা (SQL Injection রোধে)
$stmt = mysqli_prepare($conn, $sql);
if (!empty($params)) {
    mysqli_stmt_bind_param($stmt, $types, ...$params);
}
mysqli_stmt_execute($stmt);
$result = mysqli_stmt_get_result($stmt);
$doctors = mysqli_fetch_all($result, MYSQLI_ASSOC);

// বর্তমান ব্যবহারকারী রোগী (Patient) কিনা তা সেশন থেকে যাচাই করা
$isPatient = (isset($_SESSION['role']) && $_SESSION['role'] === 'patient');

// ভিউ (UI/HTML) ফাইল যুক্ত করা
require __DIR__ . "/../views/doctor-details.php";
?>