<?php
// সেশন শুরু করা হচ্ছে
session_start();

// ডাটাবেস সংযোগ ফাইল যুক্ত করা হচ্ছে
require_once __DIR__ . "/../models/db.php";

$error = '';

// ফর্ম সাবমিট করা হয়েছে কিনা তা যাচাই করা (POST রিকোয়েস্ট)
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $roleType = $_POST['role_type'] ?? 'patient';
    $password = $_POST['password'] ?? '';
    
    // নিরাপত্তার জন্য পাসওয়ার্ড হ্যাশ করা (BCRYPT অ্যালগরিদম)
    $hashedPassword = password_hash($password, PASSWORD_BCRYPT);

    // পাসওয়ার্ড দেওয়া হয়েছে কিনা তা চেক করা
    if (empty($password)) {
        $error = "Password is required.";
    } elseif ($roleType === 'patient') {
        // রোগী (Patient) রেজিস্ট্রেশন প্রসেসিং
        $username = trim($_POST['p_username'] ?? '');
        $name     = trim($_POST['p_name'] ?? '');
        $phone    = trim($_POST['p_phone'] ?? '');
        $address  = trim($_POST['p_address'] ?? '');

        // রোগীর সব ফিল্ড পূরণ করা হয়েছে কিনা যাচাই
        if (empty($username) || empty($name) || empty($phone) || empty($address)) {
            $error = "All patient fields are required.";
        } else {
            // ইউজারনেম আগে থেকেই ডাটাবেসে আছে কিনা চেক করা
            $chk = mysqli_prepare($conn, "SELECT P_ID FROM patient WHERE P_Username = ?");
            mysqli_stmt_bind_param($chk, "s", $username);
            mysqli_stmt_execute($chk);
            mysqli_stmt_store_result($chk);

            if (mysqli_stmt_num_rows($chk) > 0) {
                $error = "Username already exists. Choose another.";
            } else {
                // নতুন রোগী ডাটাবেসে ইনসার্ট করা (INSERT)
                $stmt = mysqli_prepare($conn, "INSERT INTO patient (P_Username, P_Password, P_Name, P_Phone, P_Address) VALUES (?, ?, ?, ?, ?)");
                mysqli_stmt_bind_param($stmt, "sssss", $username, $hashedPassword, $name, $phone, $address);
                
                if (mysqli_stmt_execute($stmt)) {
                    // সফল হলে লগইন পেজে রিডাইরেক্ট করা
                    header("Location: login.php");
                    exit();
                } else {
                    $error = "Failed to create patient account.";
                }
            }
        }
    } else {
        // হাসপাতাল (Hospital) রেজিস্ট্রেশন প্রসেসিং
        $hName    = trim($_POST['h_name'] ?? '');
        $hPhone   = trim($_POST['h_phone'] ?? '');
        $hAddress = trim($_POST['h_address'] ?? '');
        $hDetails = trim($_POST['h_details'] ?? '');
        $hType    = trim($_POST['h_type'] ?? 'Public');

        // হাসপাতালের সব ফিল্ড পূরণ করা হয়েছে কিনা যাচাই
        if (empty($hName) || empty($hPhone) || empty($hAddress) || empty($hDetails)) {
            $error = "All hospital fields are required.";
        } else {
            // একই নামের হাসপাতাল আগে থেকে নিবন্ধিত আছে কিনা চেক করা
            $chk = mysqli_prepare($conn, "SELECT H_ID FROM hospital WHERE H_Name = ?");
            mysqli_stmt_bind_param($chk, "s", $hName);
            mysqli_stmt_execute($chk);
            mysqli_stmt_store_result($chk);

            if (mysqli_stmt_num_rows($chk) > 0) {
                $error = "Hospital with this name is already registered.";
            } else {
                // নতুন হাসপাতাল ডাটাবেসে ইনসার্ট করা (INSERT)
                $stmt = mysqli_prepare($conn, "INSERT INTO hospital (H_Name, H_Password, H_Address, H_Phone, H_Type, H_Details) VALUES (?, ?, ?, ?, ?, ?)");
                mysqli_stmt_bind_param($stmt, "ssssss", $hName, $hashedPassword, $hAddress, $hPhone, $hType, $hDetails);
                
                if (mysqli_stmt_execute($stmt)) {
                    // সফল হলে লগইন পেজে রিডাইরেক্ট করা
                    header("Location: login.php");
                    exit();
                } else {
                    $error = "Failed to create hospital account.";
                }
            }
        }
    }
}

// রেজিস্ট্রেশন ভিউ (UI/HTML) ফাইল যুক্ত করা
require __DIR__ . "/../views/register.php";
?>