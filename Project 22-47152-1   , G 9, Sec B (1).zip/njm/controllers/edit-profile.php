<?php
// সেশন শুরু করা হচ্ছে
session_start();

// ডাটাবেস সংযোগ ফাইল যুক্ত করা হচ্ছে
require_once __DIR__ . "/../models/db.php";

// ব্যবহারকারীর রোল (Role) সেট করা আছে কিনা তা যাচাই করা; না থাকলে লগইন পেজে রিডাইরেক্ট করা হবে
if (!isset($_SESSION['role'])) {
    header("Location: login.php");
    exit();
}

// সেশন থেকে রোল এবং ব্যবহারকারীর আইডি সংগ্রহ করা
$role = $_SESSION['role'];
$userID = $_SESSION['user_id'];
$message = '';
$error = '';

// প্রোফাইল আপডেট প্রসেসিং (UPDATE)
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['update_profile'])) {
    
    // রোগীর (Patient) প্রোফাইল আপডেটের লজিক
    if ($role === 'patient') {
        $name    = trim($_POST['p_name'] ?? '');
        $phone   = trim($_POST['p_phone'] ?? '');
        $address = trim($_POST['p_address'] ?? '');

        // সব ফিল্ড পূরণ করা হয়েছে কিনা তা যাচাই করা
        if (!empty($name) && !empty($phone) && !empty($address)) {
            $stmt = mysqli_prepare($conn, "UPDATE patient SET P_Name = ?, P_Phone = ?, P_Address = ? WHERE P_ID = ?");
            mysqli_stmt_bind_param($stmt, "sssi", $name, $phone, $address, $userID);
            
            if (mysqli_stmt_execute($stmt)) {
                $_SESSION['user_name'] = $name; // সেশনে নাম আপডেট করা
                $message = "Profile updated successfully.";
            } else {
                $error = "Failed to update profile.";
            }
        } else {
            $error = "All fields are required.";
        }
    
    // হাসপাতালের (Hospital) প্রোফাইল আপডেটের লজিক
    } elseif ($role === 'hospital') {
        $name    = trim($_POST['h_name'] ?? '');
        $phone   = trim($_POST['h_phone'] ?? '');
        $address = trim($_POST['h_address'] ?? '');
        $details = trim($_POST['h_details'] ?? '');

        // সব ফিল্ড পূরণ করা হয়েছে কিনা তা যাচাই করা
        if (!empty($name) && !empty($phone) && !empty($address)) {
            $stmt = mysqli_prepare($conn, "UPDATE hospital SET H_Name = ?, H_Phone = ?, H_Address = ?, H_Details = ? WHERE H_ID = ?");
            mysqli_stmt_bind_param($stmt, "ssssi", $name, $phone, $address, $details, $userID);
            
            if (mysqli_stmt_execute($stmt)) {
                $_SESSION['user_name'] = $name; // সেশনে নাম আপডেট করা
                $message = "Hospital details updated successfully.";
            } else {
                $error = "Failed to update hospital details.";
            }
        } else {
            $error = "All fields are required.";
        }
    }
}

// পাসওয়ার্ড রিসেট প্রসেসিং
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['reset_password'])) {
    $oldPass = $_POST['old_password'] ?? '';
    $newPass = $_POST['new_password'] ?? '';

    if (!empty($oldPass) && !empty($newPass)) {
        // রোল অনুযায়ী টেবিল এবং কলামের নাম নির্ধারণ
        $table = ($role === 'patient') ? 'patient' : 'hospital';
        $idCol = ($role === 'patient') ? 'P_ID' : 'H_ID';
        $passCol = ($role === 'patient') ? 'P_Password' : 'H_Password';

        // বর্তমান হ্যাশ করা পাসওয়ার্ড ডাটাবেস থেকে তুলে আনা
        $stmt = mysqli_prepare($conn, "SELECT $passCol FROM $table WHERE $idCol = ?");
        mysqli_stmt_bind_param($stmt, "i", $userID);
        mysqli_stmt_execute($stmt);
        $res = mysqli_fetch_assoc(mysqli_stmt_get_result($stmt));

        // পুরানো পাসওয়ার্ড সত্য কিনা যাচাই করা
        if ($res && password_verify($oldPass, $res[$passCol])) {
            // নতুন পাসওয়ার্ড হ্যাশ করে আপডেট করা
            $newHashed = password_hash($newPass, PASSWORD_BCRYPT);
            $uStmt = mysqli_prepare($conn, "UPDATE $table SET $passCol = ? WHERE $idCol = ?");
            mysqli_stmt_bind_param($uStmt, "si", $newHashed, $userID);
            
            if (mysqli_stmt_execute($uStmt)) {
                $message = "Password reset successfully.";
            } else {
                $error = "Failed to reset password.";
            }
        } else {
            $error = "Incorrect current password.";
        }
    } else {
        $error = "Please fill in both password fields.";
    }
}

// অ্যাকাউন্ট মুছে ফেলা বা ডিলিট করার প্রসেসিং (DELETE)
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['delete_account'])) {
    if ($role === 'patient') {
        $stmt = mysqli_prepare($conn, "DELETE FROM patient WHERE P_ID = ?");
    } else {
        $stmt = mysqli_prepare($conn, "DELETE FROM hospital WHERE H_ID = ?");
    }
    
    mysqli_stmt_bind_param($stmt, "i", $userID);
    
    if (mysqli_stmt_execute($stmt)) {
        // সেশন ধ্বংস করে হোম পেজে রিডাইরেক্ট করা
        session_unset();
        session_destroy();
        header("Location: home.php");
        exit();
    } else {
        $error = "Failed to delete account. Ensure all dependencies are removed first.";
    }
}

// বর্তমানে লগইন থাকা ব্যবহারকারীর তথ্য ডাটাবেস থেকে নিয়ে আসা
if ($role === 'patient') {
    $stmt = mysqli_prepare($conn, "SELECT * FROM patient WHERE P_ID = ?");
    mysqli_stmt_bind_param($stmt, "i", $userID);
    mysqli_stmt_execute($stmt);
    $user = mysqli_fetch_assoc(mysqli_stmt_get_result($stmt));
} else {
    $stmt = mysqli_prepare($conn, "SELECT * FROM hospital WHERE H_ID = ?");
    mysqli_stmt_bind_param($stmt, "i", $userID);
    mysqli_stmt_execute($stmt);
    $user = mysqli_fetch_assoc(mysqli_stmt_get_result($stmt));
}

// ভিউ (UI/HTML) ফাইল যুক্ত করা
require __DIR__ . "/../views/edit-profile.php";
?>