<?php
// সেশন শুরু করা হচ্ছে
session_start();

// ডাটাবেস সংযোগ ফাইল যুক্ত করা হচ্ছে
require_once __DIR__ . "/../models/db.php";
$db = $conn; // কন্ট্রোলারের কোডের সুবিধার্থে $conn কে $db ভেরিয়েবলে ম্যাপ করা হলো

// AJAX রিকোয়েস্ট হ্যান্ডেল করার সেকশন
if (isset($_GET['action'])) {
    // রেসপন্স টাইপ JSON হিসেবে সেট করা হচ্ছে
    header('Content-Type: application/json');

    // ১. ফিডব্যাক সাবমিশন প্রসেসিং
    if ($_GET['action'] === 'submit') {
        $name = trim($_POST['patient_name'] ?? '');
        $dept = trim($_POST['department'] ?? '');
        $rating = $_POST['rating'] ?? '3';
        $comment = "[Rating: {$rating}/5] " . trim($_POST['comments'] ?? '');

        /* 
         * কুকি হ্যান্ডলিং (আনচেক করলে কুকি মুছে ফেলা)
         * - 'remember_name' চেকবক্স সিলেক্ট থাকলে ৭ দিনের জন্য কুকি সেভ হবে।
         * - আনচেক থাকলে কুকিটি এক্সপায়ার/ডিলিট করে দেওয়া হবে।
         */
        if (isset($_POST['remember_name']) && !empty($name)) {
            setcookie('feedback_patient_name', $name, time() + (86400 * 7), "/");
        } else {
            setcookie('feedback_patient_name', '', time() - 3600, "/");
        }

        /* 
         * ডাটা ভ্যালিডেশন যাচাই
         * - ডাটাবেসে ইনসার্ট করার আগে প্রয়োজনীয় ফিল্ড (নাম ও ডিপার্টমেন্ট) পূরণ আছে কিনা চেক করা।
         */
        if (empty($name) || empty($dept)) {
            echo json_encode(['status' => 'error', 'message' => 'Name and department are required.']);
            exit();
        }

        // ডাটাবেসে ফিডব্যাক ইনসার্ট করার জন্য Prepared Statement ব্যবহার
        $stmt = $db->prepare("INSERT INTO quick_feedbacks (patient_name, department, comments) VALUES (?, ?, ?)");
        $stmt->bind_param("sss", $name, $dept, $comment);
        
        // সফল হলে 'success' এবং ব্যর্থ হলে 'error' রেসপন্স পাঠানো
        echo json_encode(['status' => $stmt->execute() ? 'success' : 'error']);
        exit();
    }

    // ২. টেবিল এবং চার্টের জন্য ফিডব্যাক ডাটা নিয়ে আসা (Fetch Data)
    if ($_GET['action'] === 'fetch') {
        $dept = $_GET['dept'] ?? '';

        // নির্দিষ্ট ডিপার্টমেন্ট সিলেক্ট থাকলে সে অনুযায়ী ফিল্টার করা, অন্যথায় সব ফিডব্যাক নিয়ে আসা
        if (!empty($dept)) {
            $stmt = $db->prepare("SELECT * FROM quick_feedbacks WHERE department = ? ORDER BY id DESC");
            $stmt->bind_param("s", $dept);
            $stmt->execute();
            $list = $stmt->get_result()->fetch_all(MYSQLI_ASSOC);
        } else {
            $list = $db->query("SELECT * FROM quick_feedbacks ORDER BY id DESC")->fetch_all(MYSQLI_ASSOC);
        }

        // চার্টের জন্য প্রতিটি ডিপার্টমেন্টের মোট ফিডব্যাক সংখ্যা গণনা করা (GROUP BY)
        $stats = $db->query("SELECT department, COUNT(*) as total FROM quick_feedbacks GROUP BY department")->fetch_all(MYSQLI_ASSOC);
        
        // সব ডাটা JSON আকারে রেসপন্স পাঠানো
        echo json_encode(['data' => $list, 'stats' => $stats]);
        exit();
    }
}

// কুকি থেকে সংরক্ষিত রোগীর নাম তুলে আনা (যদি থাকে)
$cookieName = $_COOKIE['feedback_patient_name'] ?? '';

// ভিউ (UI/HTML) ফাইল যুক্ত করা
require __DIR__ . "/../views/feedback.php";
?>