<?php
// সেশন শুরু করা হচ্ছে
session_start();

// ডাটাবেস সংযোগ ফাইল যুক্ত করা হচ্ছে
require_once __DIR__ . "/../models/db.php";

// রোগী (Patient) লগইন করা আছে কিনা তা যাচাই করা; না থাকলে লগইন পেজে রিডাইরেক্ট করা হবে
if (!isset($_SESSION['patient_id'])) {
    header("Location: login.php");
    exit();
}

// URL থেকে এডমিশন আইডি এবং সেশন থেকে পেশেন্ট আইডি সংগ্রহ করা
$aID = intval($_GET['admission_id'] ?? 0);
$pID = $_SESSION['patient_id'];

// নির্দিষ্ট এডমিশন রেকর্ডের বিস্তারিত তথ্য তুলে আনার SQL (JOIN-এর মাধ্যমে)
$sql = "SELECT a.*, d.D_Name, b.B_Number, b.B_Type, h.H_Name, h.H_ID
        FROM admission a
        JOIN doctor d ON a.D_ID = d.D_ID
        JOIN bed b ON a.B_ID = b.B_ID
        JOIN hospital h ON b.H_ID = h.H_ID
        WHERE a.A_ID = ? AND a.P_ID = ?";

$stmt = mysqli_prepare($conn, $sql);
mysqli_stmt_bind_param($stmt, "ii", $aID, $pID);
mysqli_stmt_execute($stmt);
$adm = mysqli_fetch_assoc(mysqli_stmt_get_result($stmt));

// কোনো রেকর্ড না পাওয়া গেলে বা অননুমোদিত এক্সেস হলে এরর মেসেজ দেখানো
if (!$adm) {
    die("<div style='padding:20px; color:red;'>
            Invalid or unauthorized admission record.
            <a href='home.php'>Go Back</a>
         </div>");
}

/* পূর্বের পেমেন্ট রেকর্ড আছে কিনা তা পরীক্ষা করা */
$pCheck = mysqli_prepare($conn, "SELECT * FROM payment WHERE A_ID = ?");
mysqli_stmt_bind_param($pCheck, "i", $aID);
mysqli_stmt_execute($pCheck);
$existingPayment = mysqli_fetch_assoc(mysqli_stmt_get_result($pCheck));

$error = '';

/* পেমেন্ট ফর্ম সাবমিশন প্রসেস করা (যদি আগে পেমেন্ট না করা হয়ে থাকে) */
if ($_SERVER['REQUEST_METHOD'] === 'POST' && !$existingPayment) {

    $payMethod = trim($_POST['pay_method'] ?? '');
    $amount = $adm['A_Amount'];
    $fullDetails = '';

    /* পেমেন্টের ধরণ অনুযায়ী তথ্য প্রসেসিং এবং বিস্তারিত বিবরণ তৈরি */
    if ($payMethod === 'creditCard') {
        $cardName   = trim($_POST['card_name'] ?? '');
        $cardNumber = trim($_POST['card_number'] ?? '');
        $cardExpiry = trim($_POST['card_expiry'] ?? '');

        // নিরাপত্তার জন্য কার্ড নম্বর মাস্কিং (শেষ ৪টি ডিজিট দৃশ্যমান রাখা)
        $maskedCard = (strlen($cardNumber) > 4) ? '**** **** **** ' . substr($cardNumber, -4) : $cardNumber;

        $dbMethod = 'Credit Card';
        $fullDetails = "Payment Method: Credit Card\n"
                     . "Cardholder Name: " . $cardName . "\n"
                     . "Card Number: " . $maskedCard . "\n"
                     . "Expiry Date: " . $cardExpiry;

    } elseif ($payMethod === 'mobileBanking') {
        $provider = trim($_POST['mb_provider'] ?? '');
        $mbNumber = trim($_POST['mb_number'] ?? '');
        $mbTrxId  = trim($_POST['mb_trx_id'] ?? '');

        $dbMethod = 'Mobile Banking - ' . $provider;
        $fullDetails = "Payment Method: Mobile Banking\n"
                     . "Provider: " . $provider . "\n"
                     . "Mobile Number: " . $mbNumber . "\n"
                     . "Transaction ID: " . $mbTrxId;

    } elseif ($payMethod === 'cashOnPlace') {
        $dbMethod = 'Cash on Place';
        $fullDetails = "Payment Method: Cash on Place\n"
                     . "Notice: You will receive a call from the hospital in 5 minutes.";

    } else {
        $error = "Please select a valid payment method.";
    }

    // এরর না থাকলে ডাটাবেসে পেমেন্ট ইনসার্ট ও আপডেট করা
    if (!$error) {

        // ১. payment টেবিলে নতুন রেকর্ডিং যুক্ত করা (INSERT)
        $pStmt = mysqli_prepare(
            $conn,
            "INSERT INTO payment (A_ID, PA_Amount, PA_Date, PA_Method, PA_Status)
             VALUES (?, ?, NOW(), ?, 'Paid')"
        );
        mysqli_stmt_bind_param($pStmt, "ids", $aID, $amount, $dbMethod);

        // ২. admission টেবিলের A_Pament_Details কলামে বিস্তারিত পেমেন্ট সংক্রান্ত তথ্য আপডেট করা (UPDATE)
        $uStmt = mysqli_prepare(
            $conn,
            "UPDATE admission SET A_Pament_Details = ? WHERE A_ID = ?"
        );
        mysqli_stmt_bind_param($uStmt, "si", $fullDetails, $aID);

        // উভয় কোয়েরি সফলভাবে এক্সিকিউট হলে পেশেন্ট ড্যাশবোর্ডে রিডাইরেক্ট করা
        if (mysqli_stmt_execute($pStmt) && mysqli_stmt_execute($uStmt)) {
            header("Location: patient-dashboard.php");
            exit();
        } else {
            $error = "Payment processing failed. Please try again.";
        }
    }
}

// পেমেন্টের ভিউ (UI/HTML) ফাইল যুক্ত করা
require __DIR__ . "/../views/payment.php";
?>