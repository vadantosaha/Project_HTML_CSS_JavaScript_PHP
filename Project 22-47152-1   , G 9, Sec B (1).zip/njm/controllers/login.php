<?php
// সেশন শুরু করা হচ্ছে
session_start();

// ডাটাবেস সংযোগ ফাইল যুক্ত করা হচ্ছে
require_once __DIR__ . "/../models/db.php";

$error = '';

// ফর্ম সাবমিট করা হয়েছে কিনা তা যাচাই করা (POST রিকোয়েস্ট)
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $roleType = $_POST['role_type'] ?? 'patient';
    $password = $_POST['password'] ?? '';

    // পাসওয়ার্ড দেওয়া হয়েছে কিনা তা চেক করা
    if (empty($password)) {
        $error = "Please enter your password.";
    } elseif ($roleType === 'patient') {
        // রোগী (Patient) হিসেবে লগইন করার লজিক
        $username = trim($_POST['p_username'] ?? '');

        if (empty($username)) {
            $error = "Please enter your username.";
        } else {
            // ডাটাবেস থেকে রোগীর ইউজারনেম অনুযায়ী তথ্য তুলে আনা (Prepared Statement)
            $stmt = mysqli_prepare($conn, "SELECT P_ID, P_Username, P_Password, P_Name FROM patient WHERE P_Username = ?");
            mysqli_stmt_bind_param($stmt, "s", $username);
            mysqli_stmt_execute($stmt);
            $res = mysqli_stmt_get_result($stmt);

            if ($user = mysqli_fetch_assoc($res)) {
                // পাসওয়ার্ড হ্যাশ ভ্যালিডেশন চেক করা
                if (password_verify($password, $user['P_Password'])) {
                    // সেশনে রোগীর তথ্য সংরক্ষণ
                    $_SESSION['role']       = 'patient';
                    $_SESSION['user_id']    = $user['P_ID'];
                    $_SESSION['patient_id'] = $user['P_ID'];
                    $_SESSION['user_name']  = $user['P_Name'];

                    /* 
                     * কুকি সেট করা:
                     * - setcookie() এর মাধ্যমে লগইন করা ইউজারের নাম ৩০ দিনের জন্য ব্রাউজারে সেভ করা হচ্ছে।
                     * - 'Secure' (HTTPS) এবং 'HttpOnly' (JavaScript এক্সেস বন্ধ) ফ্ল্যাগ যুক্ত করে সুরক্ষা নিশ্চিত করা হয়েছে।
                     */
                    setcookie('user_name', $user['P_Name'], time() + (86400 * 30), "/", "", true, true);

                    // ড্যাশবোর্ডে রিডাইরেক্ট করা
                    header("Location: patient-dashboard.php");
                    exit();
                } else {
                    $error = "Invalid password credentials.";
                }
            } else {
                $error = "No patient account found with that username.";
            }
        }
    } elseif ($roleType === 'hospital') {
        // হাসপাতাল (Hospital) হিসেবে লগইন করার লজিক
        $hName = trim($_POST['h_name'] ?? '');

        if (empty($hName)) {
            $error = "Please enter the hospital name.";
        } else {
            // ডাটাবেস থেকে হাসপাতালের নাম অনুযায়ী তথ্য তুলে আনা
            $stmt = mysqli_prepare($conn, "SELECT H_ID, H_Name, H_Password FROM hospital WHERE H_Name = ?");
            mysqli_stmt_bind_param($stmt, "s", $hName);
            mysqli_stmt_execute($stmt);
            $res = mysqli_stmt_get_result($stmt);

            if ($hospital = mysqli_fetch_assoc($res)) {
                // পাসওয়ার্ড যাচাই করা
                if (password_verify($password, $hospital['H_Password'])) {
                    // সেশনে হাসপাতালের তথ্য সংরক্ষণ
                    $_SESSION['role']        = 'hospital';
                    $_SESSION['user_id']     = $hospital['H_ID'];
                    $_SESSION['hospital_id'] = $hospital['H_ID'];
                    $_SESSION['user_name']   = $hospital['H_Name'];

                    /* 
                     * কুকি সেট করা:
                     * - ৩০ দিনের জন্য হাসপাতালের নাম কুকিতে সেভ করে রাখা হচ্ছে।
                     * - নিরাপত্তা নিশ্চিত করতে Secure এবং HttpOnly ফ্ল্যাগ ব্যবহার করা হয়েছে।
                     */
                    setcookie('user_name', $hospital['H_Name'], time() + (86400 * 30), "/", "", true, true);

                    // হাসপাতাল ড্যাশবোর্ডে রিডাইরেক্ট করা
                    header("Location: hospital-dashboard.php");
                    exit();
                } else {
                    $error = "Invalid password credentials.";
                }
            } else {
                $error = "No registered hospital found with that name.";
            }
        }
    }
}

// লগইন ভিউ (UI/HTML) ফাইল যুক্ত করা
require __DIR__ . "/../views/login.php";
?>