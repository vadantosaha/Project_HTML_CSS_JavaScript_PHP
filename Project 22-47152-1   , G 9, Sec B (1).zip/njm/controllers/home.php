<?php
// সেশন শুরু করা হচ্ছে
session_start();

// ডাটাবেস সংযোগ ফাইল যুক্ত করা হচ্ছে
require_once __DIR__ . "/../models/db.php";

/* 
 * AJAX রিকোয়েস্ট শনাক্তকরণ:
 * - রিকোয়েস্ট হেডার 'HTTP_X_REQUESTED_WITH' এর মান 'XMLHttpRequest' কিনা অথবা URL-এ 'ajax=1' প্যারামিটার আছে কিনা তা চেক করা হচ্ছে।
 * - এর ফলে সার্ভার বুঝতে পারে এটি JS/Fetch দিয়ে পাঠানো AJAX রিকোয়েস্ট। এতে পুরো পেজ লোড না করে শুধু হাসপাতালের তালিকার আংশিক (Partial) HTML রিটার্ন করা সম্ভব হয়।
 */
$isAjax = (!empty($_SERVER['HTTP_X_REQUESTED_WITH']) && strtolower($_SERVER['HTTP_X_REQUESTED_WITH']) === 'xmlhttprequest') || isset($_GET['ajax']);

// URL (GET রিকোয়েস্ট) থেকে সার্চ ফিল্টারের মানগুলো সংগৃহীত ও ফিল্টার করা হচ্ছে
$searchLocation = trim($_GET['location'] ?? '');
$searchBedType = trim($_GET['bed_type'] ?? '');
$searchHospital = trim($_GET['hospital_name'] ?? '');
$searchHospitalType = trim($_GET['hospital_type'] ?? '');
$unreadCount = 0;

// ব্যবহারকারী লগইন করা থাকলে তার অপঠিত (Unread) নোটিফিকেশনের সংখ্যা গণনা করা
if (isset($_SESSION['role'])) {
    $userType = $_SESSION['role'];
    $userId   = ($userType === 'patient') ? ($_SESSION['patient_id'] ?? 0) : ($_SESSION['hospital_id'] ?? 0);
    
    $notifStmt = mysqli_prepare($conn, "SELECT COUNT(*) as unread FROM notification WHERE User_Type = ? AND User_ID = ? AND N_Status = 'Unread'");
    mysqli_stmt_bind_param($notifStmt, "si", $userType, $userId);
    mysqli_stmt_execute($notifStmt);
    $notifRes = mysqli_fetch_assoc(mysqli_stmt_get_result($notifStmt));
    $unreadCount = $notifRes['unread'] ?? 0;
}

// ডাইনামিক SQL কুয়েরি তৈরি: হাসপাতাল ও বেড টেবিল LEFT JOIN করা হচ্ছে
$sql = "SELECT DISTINCT h.* FROM hospital h LEFT JOIN bed b ON h.H_ID = b.H_ID WHERE 1=1";
$params = [];
$types = "";

// লোকেশন/ঠিকানা অনুযায়ী ফিল্টার যুক্ত করা
if (!empty($searchLocation)) {
    $sql .= " AND (h.H_Address LIKE ? OR h.H_Location LIKE ?)";
    $params[] = "%$searchLocation%";
    $params[] = "%$searchLocation%";
    $types .= "ss";
}

// হাসপাতালের নাম দিয়ে ফিল্টার যুক্ত করা
if (!empty($searchHospital)) {
    $sql .= " AND h.H_Name LIKE ?";
    $params[] = "%$searchHospital%";
    $types .= "s";
}

// হাসপাতালের ধরন (Hospital Type) দিয়ে ফিল্টার যুক্ত করা
if (!empty($searchHospitalType)) {
    $sql .= " AND h.H_Type = ?";
    $params[] = $searchHospitalType;
    $types .= "s";
}

// বেডের ধরন (Bed Type) দিয়ে ফিল্টার যুক্ত করা
if (!empty($searchBedType)) {
    $sql .= " AND b.B_Type = ?";
    $params[] = $searchBedType;
    $types .= "s";
}

// নতুন হাসপাতালগুলো আগে দেখানোর জন্য ID এর অবরোহী (DESC) ক্রমানুসারে সাজানো
$sql .= " ORDER BY h.H_ID DESC";
$stmt = mysqli_prepare($conn, $sql);
if (!empty($params)) {
    mysqli_stmt_bind_param($stmt, $types, ...$params);
}
mysqli_stmt_execute($stmt);
$hospitals = mysqli_fetch_all(mysqli_stmt_get_result($stmt), MYSQLI_ASSOC);

/* 
 * AJAX পারশিয়াল রেন্ডারিং রেসপন্স:
 * - $isAjax মান true হলে ob_start() দিয়ে ফিল্টার করা হাসপাতালের তালিকার HTML আউটপুট ক্যাপচার করা হয়।
 * - এর ফলে পুরো পেজ রিলোড না হয়ে শুধু ফিল্টার করা হাসপাতালের গ্রিড অংশটুকু ডাইনামিকভাবে পেজে আপডেট হতে পারে।
 */
if ($isAjax) {
    ob_start();
    ?>
    <h3>Available Hospitals (<?= count($hospitals) ?>)</h3>

    <?php if (empty($hospitals)): ?>
        <div class="alert">No matching hospitals found.</div>
    <?php else: ?>
        <div class="hospital-grid">
            <?php foreach ($hospitals as $h): ?>
                <?php
                    // প্রতিটি হাসপাতালের মোট এবং খালি (Available) বেডের সংখ্যা গণনা
                    $bStmt = mysqli_prepare($conn, "SELECT COUNT(*) as total, SUM(CASE WHEN B_Status = 'Available' THEN 1 ELSE 0 END) as avail FROM bed WHERE H_ID = ?");
                    mysqli_stmt_bind_param($bStmt, "i", $h['H_ID']);
                    mysqli_stmt_execute($bStmt);
                    $bedStats = mysqli_fetch_assoc(mysqli_stmt_get_result($bStmt));

                    // প্রতিটি হাসপাতালের ডাক্তারের সংখ্যা গণনা
                    $dStmt = mysqli_prepare($conn, "SELECT COUNT(*) as doc_count FROM doctor WHERE H_ID = ?");
                    mysqli_stmt_bind_param($dStmt, "i", $h['H_ID']);
                    mysqli_stmt_execute($dStmt);
                    $docData = mysqli_fetch_assoc(mysqli_stmt_get_result($dStmt));
                ?>
                <div class="hospital-card">
                    <div>
                        <h3> Hospital Name: <?= htmlspecialchars($h['H_Name']) ?></h3>
                        <p> Hospital Address: <?= htmlspecialchars($h['H_Address']) ?></p>
                        <p> Hospital Phone: <?= htmlspecialchars($h['H_Phone']) ?></p>

                        <div class="stats-row">
                            <span><strong>Beds Available:</strong> <?= $bedStats['avail'] ?? 0 ?></span>
                            <span><strong>Doctors:</strong> <?= $docData['doc_count'] ?? 0 ?></span>
                        </div>
                    </div>

                    <div class="card-actions">
                        <?php if (isset($_SESSION['role']) && $_SESSION['role'] === 'patient'): ?>
                            <a href="admission.php?hospital_id=<?= $h['H_ID'] ?>" class="btn btn-success" style="flex:1; text-align:center;">Book Bed</a>
                        <?php else: ?>
                            <a href="login.php" class="btn btn-success" style="flex:1; text-align:center;" onclick="alert('Please login as a patient to book a bed.');">Book Bed</a>
                        <?php endif; ?>
                    </div>
                </div>
            <?php endforeach; ?>
        </div>
    <?php endif; ?>
    <?php
    // বাফার আউটপুট প্রিন্ট করে কোড এক্সিকিউশন বন্ধ করা হচ্ছে
    echo ob_get_clean();
    exit();
}

// ভিউ (UI/HTML) ফাইল যুক্ত করা
require __DIR__ . "/../views/home.php";
?>