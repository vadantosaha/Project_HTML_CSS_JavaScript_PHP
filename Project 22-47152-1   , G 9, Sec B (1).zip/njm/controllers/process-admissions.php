<?php
// সেশন শুরু করা হচ্ছে
session_start();

// ডাটাবেস সংযোগ ফাইল যুক্ত করা হচ্ছে
require_once __DIR__ . "/../models/db.php";

// হাসপাতাল (Hospital) লগইন করা আছে কিনা তা যাচাই করা; না থাকলে লগইন পেজে রিডাইরেক্ট করা হবে
if (!isset($_SESSION['hospital_id'])) {
    header("Location: login.php");
    exit();
}

// সেশন থেকে হাসপাতালের আইডি এবং মেসেজ ভেরিয়েবল ইনিশিয়ালাইজ করা
$hID = $_SESSION['hospital_id'];
$message = '';
$error = '';

// ভর্তি আবেদন অনুমোদন (Approve) বা প্রত্যাখ্যান (Reject) করার প্রসেসিং
if (isset($_GET['action']) && isset($_GET['admission_id'])) {
    $action = $_GET['action'];
    $aID = intval($_GET['admission_id']);

    if ($action === 'approve') {
        // ১. এডমিশন স্ট্যাটাস 'Approved' করা (UPDATE)
        $uAdm = mysqli_prepare($conn, "UPDATE admission SET A_Status = 'Approved' WHERE A_ID = ?");
        mysqli_stmt_bind_param($uAdm, "i", $aID);
        
        // ২. সংশ্লিষ্ট বেডের স্ট্যাটাস 'Occupied' (বুকড) হিসেবে আপডেট করা
        $getBed = mysqli_query($conn, "SELECT B_ID FROM admission WHERE A_ID = $aID");
        $bRow = mysqli_fetch_assoc($getBed);
        if ($bRow) {
            $bID = $bRow['B_ID'];
            mysqli_query($conn, "UPDATE bed SET B_Status = 'Occupied' WHERE B_ID = $bID");
        }

        if (mysqli_stmt_execute($uAdm)) {
            $message = "Admission approved successfully.";
        } else {
            $error = "Failed to approve admission.";
        }
    } elseif ($action === 'reject') {
        // ১. এডমিশন স্ট্যাটাস 'Rejected' করা (UPDATE)
        $uAdm = mysqli_prepare($conn, "UPDATE admission SET A_Status = 'Rejected' WHERE A_ID = ?");
        mysqli_stmt_bind_param($uAdm, "i", $aID);

        // ২. ভর্তি বাতিল হওয়ায় বেডের স্ট্যাটাস পুনরায় 'Available' করা
        $getBed = mysqli_query($conn, "SELECT B_ID FROM admission WHERE A_ID = $aID");
        $bRow = mysqli_fetch_assoc($getBed);
        if ($bRow) {
            $bID = $bRow['B_ID'];
            mysqli_query($conn, "UPDATE bed SET B_Status = 'Available' WHERE B_ID = $bID");
        }

        if (mysqli_stmt_execute($uAdm)) {
            $message = "Admission request rejected.";
        } else {
            $error = "Failed to reject admission.";
        }
    }
}

// এই হাসপাতালের অধীনে থাকা সমস্ত ভর্তি আবেদন এবং পেমেন্টের তথ্য ডাটাবেস থেকে তুলে আনা (JOIN)
$listStmt = mysqli_prepare($conn, "
    SELECT a.A_ID, a.A_Date, a.A_Details, a.A_Amount, a.A_Status, a.A_Pament_Details,
           p.P_Name, d.D_Name, b.B_Number,
           pay.PA_Method, pay.PA_Status
    FROM admission a
    LEFT JOIN patient p ON a.P_ID = p.P_ID
    LEFT JOIN doctor d ON a.D_ID = d.D_ID
    LEFT JOIN bed b ON a.B_ID = b.B_ID
    LEFT JOIN payment pay ON a.A_ID = pay.A_ID
    WHERE b.H_ID = ?
    ORDER BY a.A_ID DESC
");
mysqli_stmt_bind_param($listStmt, "i", $hID);
mysqli_stmt_execute($listStmt);
$admissions = mysqli_fetch_all(mysqli_stmt_get_result($listStmt), MYSQLI_ASSOC);

// এডমিশন প্রসেসিংয়ের ভিউ (UI/HTML) ফাইল যুক্ত করা
require __DIR__ . "/../views/process-admissions.php";
?>