<?php
// সেশন শুরু করা হচ্ছে
session_start();

// ডাটাবেস সংযোগ ফাইল যুক্ত করা হচ্ছে
require_once __DIR__ . "/../models/db.php";

// ব্যবহারকারী লগইন করা আছে কিনা তা রোল (role) দিয়ে যাচাই করা; না থাকলে লগইন পেজে রিডাইরেক্ট করা হবে
if (!isset($_SESSION['role'])) {
    header("Location: login.php");
    exit();
}

// সেশন থেকে ইউজারের টাইপ (Patient/Hospital) এবং সে অনুযায়ী আইডেন্টিফায়ার (ID) নির্ধারণ
$userType = $_SESSION['role'];
$userId   = ($userType === 'patient') ? ($_SESSION['patient_id'] ?? 0) : ($_SESSION['hospital_id'] ?? 0);

// নোটিফিকেশন "পঠিত" (Read) হিসেবে মার্ক করার প্রসেসিং (UPDATE)
if (isset($_GET['action']) && $_GET['action'] === 'mark_read') {
    // নির্দিষ্ট ইউজার টাইপ এবং আইডির সব নোটিফিকেশনের স্ট্যাটাস 'Read' করা
    $mStmt = mysqli_prepare($conn, "UPDATE notification SET N_Status = 'Read' WHERE User_Type = ? AND User_ID = ?");
    mysqli_stmt_bind_param($mStmt, "si", $userType, $userId);
    mysqli_stmt_execute($mStmt);
    
    // আপডেট শেষে নোটিফিকেশন পেজে রিডাইরেক্ট করা
    header("Location: notifications.php");
    exit();
}

// উক্ত ব্যবহারকারীর সমস্ত নোটিফিকেশন ডাটাবেস থেকে তুলে আনা (সর্বশেষ নোটিফিকেশন আগে দেখাবে)
$stmt = mysqli_prepare($conn, "SELECT * FROM notification WHERE User_Type = ? AND User_ID = ? ORDER BY N_Date DESC");
mysqli_stmt_bind_param($stmt, "si", $userType, $userId);
mysqli_stmt_execute($stmt);
$result = mysqli_stmt_get_result($stmt);
$notifications = mysqli_fetch_all($result, MYSQLI_ASSOC);

// নোটিফিকেশনের ভিউ (UI/HTML) ফাইল যুক্ত করা
require __DIR__ . "/../views/notifications.php";
?>