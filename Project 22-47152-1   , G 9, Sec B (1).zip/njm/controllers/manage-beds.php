<?php
// সেশন শুরু করা হচ্ছে
session_start();

// ডাটাবেস সংযোগ ফাইল যুক্ত করা হচ্ছে
require_once __DIR__ . "/../models/db.php";

// হাসপাতাল (Hospital) লগইন করা আছে কিনা তা যাচাই করা; না থাকলে লগইন পেজে রিডাইরেক্ট করা হবে
if (!isset($_SESSION['hospital_id'])) {
    header("Location: login.php");
    exit();
}

// সেশন থেকে হাসপাতালের আইডি এবং মেসেজ ভেরিয়েবল ইনিশিয়ালাইজ করা
$hID = $_SESSION['hospital_id'];
$message = '';
$error = '';

// নতুন বেড যুক্ত করার প্রসেসিং (INSERT)
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['add_bed'])) {
    $bNum   = trim($_POST['bed_number'] ?? '');
    $bType  = trim($_POST['bed_type'] ?? 'General');
    $bPrice = floatval($_POST['bed_price'] ?? 0);

    // বেড নম্বর এবং মূল্যের সঠিকতা যাচাই করা
    if (empty($bNum) || $bPrice <= 0) {
        $error = "Please provide a valid bed number and price.";
    } else {
        // ডাটাবেসে নতুন বেড ইনসার্ট করার জন্য Prepared Statement
        $stmt = mysqli_prepare($conn, "INSERT INTO bed (H_ID, B_Number, B_Type, B_Price, B_Status) VALUES (?, ?, ?, ?, 'Available')");
        mysqli_stmt_bind_param($stmt, "issd", $hID, $bNum, $bType, $bPrice);
        
        if (mysqli_stmt_execute($stmt)) {
            $message = "Bed added successfully.";
        } else {
            $error = "Failed to add bed. Bed number might already exist.";
        }
    }
}

// বেড মুছে ফেলার প্রসেসিং (DELETE)
if (isset($_GET['delete'])) {
    $delBedId = intval($_GET['delete']);
    
    // নির্দিষ্ট হাসপাতাল এবং বেড আইডি মিলিয়ে ডাটাবেস থেকে মুছে ফেলা
    $stmt = mysqli_prepare($conn, "DELETE FROM bed WHERE B_ID = ? AND H_ID = ?");
    mysqli_stmt_bind_param($stmt, "ii", $delBedId, $hID);
    
    if (mysqli_stmt_execute($stmt)) {
        $message = "Bed deleted successfully.";
    } else {
        $error = "Failed to delete bed.";
    }
}

// এই হাসপাতালের সকল বেডের তালিকা ডাটাবেস থেকে তুলে আনা (নতুনগুলো আগে দেখাবে)
$bQuery = mysqli_prepare($conn, "SELECT * FROM bed WHERE H_ID = ? ORDER BY B_ID DESC");
mysqli_stmt_bind_param($bQuery, "i", $hID);
mysqli_stmt_execute($bQuery);
$beds = mysqli_fetch_all(mysqli_stmt_get_result($bQuery), MYSQLI_ASSOC);

// বেড ম্যানেজমেন্টের ভিউ (UI/HTML) ফাইল যুক্ত করা
require __DIR__ . "/../views/manage-beds.php";
?>