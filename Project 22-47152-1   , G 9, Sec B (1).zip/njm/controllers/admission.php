<?php
// সেশন শুরু করা হচ্ছে
session_start();

// ডাটাবেস সংযোগ ফাইল যুক্ত করা হচ্ছে
require_once __DIR__ . "/../models/db.php";

// রোগী (Patient) লগইন করা আছে কিনা তা যাচাই করা; না থাকলে লগইন পেজে রিডাইরেক্ট করা হবে
if (!isset($_SESSION['patient_id'])) {
    header("Location: login.php");
    exit();
}

// সেশন থেকে রোগীর আইডি এবং এরর মেসেজের জন্য ভেরিয়েবল ইনিশিয়ালাইজ করা
$pID = $_SESSION['patient_id'];
$error = '';

// URL (GET রিকোয়েস্ট) থেকে ডাক্তার, বেড এবং হাসপাতালের আইডি সংগ্রহ করা
$preDoctorId = intval($_GET['doctor_id'] ?? 0);
$preBedId = intval($_GET['bed_id'] ?? 0);
$selectedHospitalId = intval($_GET['hospital_id'] ?? 0);

// যদি ডাক্তার আইডি থাকে কিন্তু হাসপাতাল আইডি না থাকে, তবে ডাক্তারের আইডি দিয়ে হাসপাতাল খুঁজে বের করা
if ($selectedHospitalId <= 0 && $preDoctorId > 0) {
    $stmt = mysqli_prepare($conn, "SELECT H_ID FROM doctor WHERE D_ID = ?");
    mysqli_stmt_bind_param($stmt, "i", $preDoctorId);
    mysqli_stmt_execute($stmt);
    $row = mysqli_fetch_assoc(mysqli_stmt_get_result($stmt));

    if ($row) {
        $selectedHospitalId = $row['H_ID'];
    }
}

// যদি বেড আইডি থাকে কিন্তু হাসপাতাল আইডি না থাকে, তবে বেড আইডি দিয়ে হাসপাতাল খুঁজে বের করা
if ($selectedHospitalId <= 0 && $preBedId > 0) {
    $stmt = mysqli_prepare($conn, "SELECT H_ID FROM bed WHERE B_ID = ?");
    mysqli_stmt_bind_param($stmt, "i", $preBedId);
    mysqli_stmt_execute($stmt);
    $row = mysqli_fetch_assoc(mysqli_stmt_get_result($stmt));

    if ($row) {
        $selectedHospitalId = $row['H_ID'];
    }
}

/* অ্যাডমিশন (Admission) ফর্ম সাবমিট প্রসেসিং */
if ($_SERVER['REQUEST_METHOD'] === 'POST') {

    // ফর্ম (POST রিকোয়েস্ট) থেকে তথ্য গ্রহণ ও ফিল্টার করা
    $hID = intval($_POST['hospital_id'] ?? 0);
    $dID = intval($_POST['doctor_id'] ?? 0);
    $bID = intval($_POST['bed_id'] ?? 0);
    $aDate = trim($_POST['admission_date'] ?? '');
    $aDetails = trim($_POST['admission_details'] ?? '');

    // প্রয়োজনীয় সকল ফিল্ড সঠিকভাবে পূরণ করা হয়েছে কিনা তা যাচাই করা
    if ($hID <= 0 || $dID <= 0 || $bID <= 0 || empty($aDate)) {

        $error = "Please complete all required selection fields.";

    } else {
        /* ডাক্তার ওই হাসপাতালের কিনা তা যাচাই করা */
        $stmt = mysqli_prepare(
            $conn,
            "SELECT H_ID FROM doctor WHERE D_ID = ?"
        );

        mysqli_stmt_bind_param($stmt, "i", $dID);
        mysqli_stmt_execute($stmt);
        $doctor = mysqli_fetch_assoc(mysqli_stmt_get_result($stmt));

        /* বেড ওই হাসপাতালের কিনা এবং বেডের সার্বিক তথ্য যাচাই করা */
        $stmt = mysqli_prepare(
            $conn,
            "SELECT H_ID, B_Price, B_Status, B_Number
             FROM bed WHERE B_ID = ?"
        );

        mysqli_stmt_bind_param($stmt, "i", $bID);
        mysqli_stmt_execute($stmt);
        $bed = mysqli_fetch_assoc(mysqli_stmt_get_result($stmt));

        // বিভিন্ন শর্ত অনুযায়ী এরর হ্যান্ডলিং
        if (!$doctor || $doctor['H_ID'] != $hID) {

            $error = "Selected doctor does not belong to the selected hospital.";

        } elseif (!$bed || $bed['H_ID'] != $hID) {

            $error = "Selected bed does not belong to the selected hospital.";

        } elseif ($bed['B_Status'] !== 'Available') {

            $error = "Selected bed is no longer available.";

        } else {

            // বেডের ভাড়া নির্ধারণ
            $amount = $bed['B_Price'];

            // ডাটাবেসে অ্যাডমিশনের নতুন রেকর্ড যুক্ত করা (Status: Pending)
            $stmt = mysqli_prepare(
                $conn,
                "INSERT INTO admission
                (P_ID, D_ID, B_ID, A_Date, A_Details, A_Amount, A_Status)
                VALUES (?, ?, ?, ?, ?, ?, 'Pending')"
            );

            mysqli_stmt_bind_param(
                $stmt,
                "iiissd",
                $pID,
                $dID,
                $bID,
                $aDate,
                $aDetails,
                $amount
            );

            if (mysqli_stmt_execute($stmt)) {

                $admissionId = mysqli_insert_id($conn);
                $pName = $_SESSION['user_name'] ?? 'A patient';

                /* হাসপাতাল প্যানেলের জন্য নোটিফিকেশন তৈরি */
                $message = "New admission request (#A$admissionId) for Bed #"
                    . $bed['B_Number'] . " submitted by $pName.";

                $stmt = mysqli_prepare(
                    $conn,
                    "INSERT INTO notification
                    (User_Type, User_ID, N_Message, N_Status, N_Date)
                    VALUES ('hospital', ?, ?, 'Unread', NOW())"
                );

                mysqli_stmt_bind_param($stmt, "is", $hID, $message);
                mysqli_stmt_execute($stmt);

                /* রোগী প্যানেলের জন্য নোটিফিকেশন তৈরি */
                $message = "Your request for Bed #"
                    . $bed['B_Number']
                    . " (Admission #A"
                    . $admissionId
                    . ") has been submitted successfully.";

                $stmt = mysqli_prepare(
                    $conn,
                    "INSERT INTO notification
                    (User_Type, User_ID, N_Message, N_Status, N_Date)
                    VALUES ('patient', ?, ?, 'Unread', NOW())"
                );

                mysqli_stmt_bind_param($stmt, "is", $pID, $message);
                mysqli_stmt_execute($stmt);

                // সফলভাবে সাবমিট হলে পেমেন্ট পেজে রিডাইরেক্ট করা
                header("Location: payment.php?admission_id=" . $admissionId);
                exit();

            } else {

                $error = "Failed to submit admission request.";
            }
        }
    }
}


/* ড্রপডাউনের জন্য সকল হাসপাতালের তালিকা নিয়ে আসা */
$result = mysqli_query(
    $conn,
    "SELECT H_ID, H_Name FROM hospital ORDER BY H_Name ASC"
);

$hospitals = mysqli_fetch_all($result, MYSQLI_ASSOC);

$doctors = [];
$beds = [];
$hospital = null;


/* নির্বাচিত হাসপাতালের বিস্তারিত তথ্য, ডাক্তার ও খালি বেডের তালিকা সংগ্রহ */
if ($selectedHospitalId > 0) {

    /* হাসপাতালের বিস্তারিত তথ্য */
    $stmt = mysqli_prepare(
        $conn,
        "SELECT H_ID, H_Name, H_Address, H_Phone, H_Type, H_Details
         FROM hospital WHERE H_ID = ?"
    );

    mysqli_stmt_bind_param($stmt, "i", $selectedHospitalId);
    mysqli_stmt_execute($stmt);
    $hospital = mysqli_fetch_assoc(mysqli_stmt_get_result($stmt));


    /* উক্ত হাসপাতালের ডাক্তারদের তালিকা */
    $stmt = mysqli_prepare(
        $conn,
        "SELECT D_ID, D_Name, D_specialty, D_Phone
         FROM doctor
         WHERE H_ID = ?
         ORDER BY D_Name ASC"
    );

    mysqli_stmt_bind_param($stmt, "i", $selectedHospitalId);
    mysqli_stmt_execute($stmt);
    $doctors = mysqli_fetch_all(
        mysqli_stmt_get_result($stmt),
        MYSQLI_ASSOC
    );


    /* উক্ত হাসপাতালের খালি (Available) বেডগুলোর তালিকা */
    $stmt = mysqli_prepare(
        $conn,
        "SELECT B_ID, B_Number, B_Type, B_Price
         FROM bed
         WHERE H_ID = ?
         AND B_Status = 'Available'
         ORDER BY B_Number ASC"
    );

    mysqli_stmt_bind_param($stmt, "i", $selectedHospitalId);
    mysqli_stmt_execute($stmt);
    $beds = mysqli_fetch_all(
        mysqli_stmt_get_result($stmt),
        MYSQLI_ASSOC
    );
}

// ভিউ (UI/HTML) ফাইল যুক্ত করা
require __DIR__ . "/../views/admission.php";
?>